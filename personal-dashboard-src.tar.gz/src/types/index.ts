export interface ModuleConfig {
  id: string;
  name: string;
  icon: string;
  route: string;
  order: number;
  visible: boolean;
  description: string;
  badge?: string;
}

export interface Paper {
  id: string;
  title: string;
  authors: string;
  journal: string;
  date: string;
  abstract: string;
  tags: string[];
  week: number;
  year: number;
}

export interface ExperimentNote {
  id: string;
  date: string;
  title: string;
  content: string;
  tags: string[];
  week: number;
  year: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  cover: string;
  rating: number;
  status: 'reading' | 'finished' | 'want-to-read';
  isPhysical: boolean;
  needReread: boolean;
  tags: string[];
  startedDate?: string;
  finishedDate?: string;
  thoughts: string[];
  progress: number;
}

export interface ReadingStats {
  week: number;
  year: number;
  booksRead: number;
  totalMinutes: number;
  categories: Record<string, number>;
  dailyMinutes: { day: string; minutes: number }[];
}

export interface MediaItem {
  id: string;
  title: string;
  type: 'movie' | 'tv';
  poster: string;
  rating: number;
  review: string;
  watchCount: number;
  tags: string[];
  lastWatchedDate?: string;
  year: number;
}

export interface JobPosition {
  id: string;
  company: string;
  position: string;
  link: string;
  status: 'interested' | 'applied' | 'interview' | 'offer' | 'rejected';
  postedDate: string;
  category: string;
  interviewDate?: string;
  notes: string;
  salary?: string;
  location?: string;
}

export interface InterviewExperience {
  id: string;
  company: string;
  date: string;
  round: string;
  questions: string;
  summary: string;
  tags: string[];
}

export interface IeltsModule {
  id: 'listening' | 'speaking' | 'reading' | 'writing' | 'vocabulary';
  name: string;
  totalHours: number;
  targetScore: number;
  currentScore: number;
}

export interface StudyRecord {
  id: string;
  date: string;
  module: string;
  duration: number;
  content: string;
}

export interface CheckInRecord {
  date: string;
  completed: boolean;
  modules: string[];
}

export interface HealthData {
  date: string;
  weight?: number;
  bodyFat?: number;
  muscleMass?: number;
  steps?: number;
  exerciseMinutes?: number;
  sleepHours?: number;
  water?: number;
}

export interface NutrientSummary {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface AINutritionAdvice {
  overall: string;
  suggestions: string[];
  warnings: string[];
  score: number;
}

export interface MealRecord {
  id: string;
  date: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface Supplement {
  id: string;
  name: string;
  dosage: string;
  time: string;
  takenDates: string[];
}

export interface FitnessGoal {
  id: string;
  type: 'weight' | 'body-fat' | 'muscle';
  targetValue: number;
  currentValue: number;
  startValue: number;
  startDate: string;
  targetDate: string;
  unit: string;
}

export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  category?: string;
}
