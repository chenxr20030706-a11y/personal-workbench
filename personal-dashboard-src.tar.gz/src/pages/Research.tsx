import { useState, useRef, useEffect, useCallback } from 'react';
import {
  FlaskConical,
  FileText,
  MessageCircle,
  Calendar,
  Plus,
  Send,
  Tag,
  Clock,
  BookOpen,
  Sparkles,
  Bot,
  User,
  GitBranch,
  X,
  Upload,
  Link as LinkIcon,
  Download,
  FileText as FileTextIcon,
  CheckCircle2,
  Loader2,
  Network,
  Trash2,
  Lightbulb,
  ChevronLeft,
  ChevronRight,
  Eye,
  RefreshCw,
  Search,
  AlertCircle,
  Check,
} from 'lucide-react';
import { useResearchStore } from '../store/useResearchStore';
import { formatDate, getWeekNumber } from '../utils/date';

type TabType = 'papers' | 'ai' | 'notes' | 'ppt';

const quickQuestions = [
  '如何设计对照实验？',
  'WB实验条带弥散怎么办？',
  '细胞污染如何处理？',
  'PCR实验优化建议',
  '生物正交反应有哪些类型？',
];

export default function Research() {
  const [activeTab, setActiveTab] = useState<TabType>('papers');
  const {
    papers,
    experimentNotes,
    chatMessages,
    isChatLoading,
    pptData,
    isGeneratingPPT,
    sendMessage,
    addPaper,
    addExperimentNote,
    clearChat,
    exportMindMap,
    generatePPT,
    downloadPPT,
    downloadSpeech,
    generateWeeklyReport,
    batchImportPapers,
    generateMindMap,
  } = useResearchStore();
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const today = new Date();
  const currentWeek = getWeekNumber(today);

  const [showAddPaper, setShowAddPaper] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [showMindMap, setShowMindMap] = useState<string | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showPPTViewer, setShowPPTViewer] = useState(false);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [showSpeechModal, setShowSpeechModal] = useState(false);
  const [showBatchImport, setShowBatchImport] = useState(false);
  const [batchImportText, setBatchImportText] = useState('');
  const [importSuccess, setImportSuccess] = useState<number | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [newPaper, setNewPaper] = useState({
    title: '',
    authors: '',
    journal: '',
    date: '',
    abstract: '',
    tags: '',
  });

  const [newNote, setNewNote] = useState({
    title: '',
    content: '',
    date: '',
    tags: '',
  });

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSend = () => {
    if (!input.trim()) return;
    sendMessage(input);
    setInput('');
  };

  const thisWeekPapers = papers.filter(
    (p) => p.week === currentWeek && p.year === today.getFullYear()
  );

  const filteredPapers = papers.filter(p => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      p.title.toLowerCase().includes(query) ||
      p.authors.toLowerCase().includes(query) ||
      p.journal.toLowerCase().includes(query) ||
      p.tags.some(t => t.toLowerCase().includes(query))
    );
  });

  const handleAddPaper = () => {
    if (!newPaper.title.trim()) {
      showToast('请输入文献标题', 'error');
      return;
    }
    addPaper({
      title: newPaper.title,
      authors: newPaper.authors,
      journal: newPaper.journal,
      date: newPaper.date || new Date().toISOString().split('T')[0],
      abstract: newPaper.abstract,
      tags: newPaper.tags.split(/[,，]/).map(t => t.trim()).filter(Boolean),
    });
    setNewPaper({ title: '', authors: '', journal: '', date: '', abstract: '', tags: '' });
    setShowAddPaper(false);
    showToast('文献添加成功', 'success');
  };

  const handleAddNote = () => {
    if (!newNote.title.trim()) {
      showToast('请输入实验记录标题', 'error');
      return;
    }
    addExperimentNote({
      title: newNote.title,
      content: newNote.content,
      date: newNote.date || new Date().toISOString().split('T')[0],
      tags: newNote.tags.split(/[,，]/).map(t => t.trim()).filter(Boolean),
    });
    setNewNote({ title: '', content: '', date: '', tags: '' });
    setShowAddNote(false);
    showToast('实验记录保存成功', 'success');
  };

  const handleGeneratePPT = async () => {
    await generatePPT();
    showToast('PPT生成完成', 'success');
  };

  const handleQuickQuestion = (question: string) => {
    setInput(question);
    sendMessage(question);
    setInput('');
  };

  const handleBatchImport = () => {
    try {
      const lines = batchImportText.trim().split('\n').filter(line => line.trim());
      if (lines.length === 0) {
        showToast('请输入要导入的文献数据', 'error');
        return;
      }
      const newPapers = lines.map(line => {
        const parts = line.split('|').map(p => p.trim());
        return {
          title: parts[0] || '未命名文献',
          authors: parts[1] || '',
          journal: parts[2] || '',
          date: parts[3] || new Date().toISOString().split('T')[0],
          abstract: parts[4] || '',
          tags: parts[5] ? parts[5].split(/[,，]/).map(t => t.trim()).filter(Boolean) : [],
        };
      });
      const count = batchImportPapers(newPapers);
      setImportSuccess(count);
      setBatchImportText('');
      showToast(`成功导入 ${count} 篇文献`, 'success');
      setTimeout(() => {
        setShowBatchImport(false);
        setImportSuccess(null);
      }, 1500);
    } catch (e) {
      console.error('批量导入失败:', e);
      showToast('批量导入失败，请检查格式', 'error');
    }
  };

  const handleExportMindMap = (format: 'png' | 'json' | 'text') => {
    if (showMindMap) {
      exportMindMap(showMindMap, format);
      showToast(`已导出为 ${format.toUpperCase()} 格式`, 'success');
    }
    setShowExportMenu(false);
  };

  const handleGenerateWeeklyReport = () => {
    generateWeeklyReport();
    showToast('周报生成成功，已开始下载', 'success');
  };

  const handleDownloadPPT = () => {
    downloadPPT();
    showToast('PPT下载已开始', 'success');
  };

  const handleDownloadSpeech = () => {
    downloadSpeech();
    showToast('演讲稿下载已开始', 'success');
  };

  const handleClearChat = () => {
    if (chatMessages.length > 1) {
      clearChat();
      showToast('对话已清空', 'info');
    }
  };

  const tabs = [
    { id: 'papers', label: '文献推送', icon: FileText },
    { id: 'ai', label: 'AI实验指导', icon: MessageCircle },
    { id: 'notes', label: '实验周报', icon: Calendar },
    { id: 'ppt', label: 'PPT生成', icon: Sparkles },
  ];

  const MindMapComponent = ({ paperId }: { paperId: string }) => {
    const paper = papers.find(p => p.id === paperId);
    if (!paper) return null;
    
    const branches = [
      { label: '研究背景', color: '#A78BFA', items: ['研究意义', '研究现状', '科学问题'] },
      { label: '实验方法', color: '#F472B6', items: ['实验设计', '材料试剂', '检测方法'] },
      { label: '关键发现', color: '#34D399', items: ['主要结果', '数据验证', '机制分析'] },
      { label: '结论展望', color: '#FB923C', items: ['研究结论', '创新点', '未来方向'] },
    ];

    return (
      <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={() => { setShowMindMap(null); setShowExportMenu(false); }}>
        <div className="glass-card rounded-3xl max-w-4xl w-full max-h-[85vh] overflow-hidden animate-scale-in flex flex-col" onClick={e => e.stopPropagation()}>
          <div className="p-6 border-b border-purple-100/50 flex items-center justify-between flex-shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center">
                <Network className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-purple-800">文献思维导图</h3>
                <p className="text-xs text-purple-500">{paper.journal} · {paper.date}</p>
              </div>
            </div>
            <button onClick={() => { setShowMindMap(null); setShowExportMenu(false); }} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
              <X className="w-5 h-5 text-purple-500" />
            </button>
          </div>
          
          <div className="p-6 overflow-auto flex-1 bg-gradient-to-br from-purple-50/30 to-pink-50/30">
            <h4 className="font-semibold text-purple-800 mb-6 text-lg text-center px-4">{paper.title}</h4>
            
            <div className="relative">
              <div className="flex justify-center mb-8">
                <div className="px-6 py-3 gradient-bg text-white rounded-xl font-medium text-center shadow-soft-lg max-w-md">
                  核心主题
                  <div className="text-xs opacity-80 mt-1">生物正交化学研究</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 relative">
                <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ top: 0, zIndex: 0 }}>
                  <line x1="50%" y1="30" x2="15%" y2="100" stroke="#A78BFA" strokeWidth="2.5" strokeLinecap="round" />
                  <line x1="50%" y1="30" x2="85%" y2="100" stroke="#F472B6" strokeWidth="2.5" strokeLinecap="round" />
                  <line x1="50%" y1="30" x2="15%" y2="280" stroke="#34D399" strokeWidth="2.5" strokeLinecap="round" />
                  <line x1="50%" y1="30" x2="85%" y2="280" stroke="#FB923C" strokeWidth="2.5" strokeLinecap="round" />
                </svg>

                {branches.map((branch, idx) => (
                  <div key={idx} className="space-y-3 relative z-10">
                    <div className="p-4 bg-white/90 backdrop-blur rounded-xl shadow-soft border" style={{ borderColor: branch.color + '40' }}>
                      <p className="text-sm font-semibold mb-2 flex items-center gap-2" style={{ color: branch.color }}>
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: branch.color }} />
                        {branch.label}
                      </p>
                      <div className="space-y-1.5">
                        {branch.items.map((item, i) => (
                          <div key={i} className="flex items-center gap-2 px-2 py-1.5 rounded-lg" style={{ backgroundColor: branch.color + '15' }}>
                            <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: branch.color }} />
                            <span className="text-xs text-gray-600">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 p-4 bg-blue-50/80 rounded-xl border border-blue-200">
                <p className="text-sm font-semibold text-blue-700 mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                  关键词
                </p>
                <div className="flex flex-wrap gap-2">
                  {paper.tags.map((tag, i) => (
                    <span key={i} className="px-3 py-1 bg-white text-blue-600 text-xs rounded-full border border-blue-200">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-6 border-t border-purple-100/50 flex gap-3 flex-shrink-0 bg-white/50">
            <div className="flex-1 relative">
              <button 
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="w-full flex items-center justify-center gap-2 py-3 gradient-btn text-white rounded-xl text-sm font-medium hover:opacity-95 transition-opacity"
              >
                <Download className="w-4 h-4" />
                导出思维导图
              </button>
              {showExportMenu && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-white rounded-xl shadow-xl border border-purple-100 overflow-hidden z-20">
                  <button 
                    onClick={() => handleExportMindMap('png')}
                    className="w-full px-4 py-2.5 text-left text-sm text-purple-700 hover:bg-purple-50 transition-colors flex items-center gap-2"
                  >
                    <FileTextIcon className="w-4 h-4" />
                    导出为 PNG 图片
                  </button>
                  <button 
                    onClick={() => handleExportMindMap('json')}
                    className="w-full px-4 py-2.5 text-left text-sm text-purple-700 hover:bg-purple-50 transition-colors flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    导出为 JSON 数据
                  </button>
                  <button 
                    onClick={() => handleExportMindMap('text')}
                    className="w-full px-4 py-2.5 text-left text-sm text-purple-700 hover:bg-purple-50 transition-colors flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    导出为文本大纲
                  </button>
                </div>
              )}
            </div>
            <button onClick={() => { setShowMindMap(null); setShowExportMenu(false); }} className="px-8 py-3 bg-purple-100 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-200 transition-colors">
              关闭
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 relative">
      {toast && (
        <div className={`fixed top-20 right-6 z-50 px-4 py-3 rounded-xl shadow-lg animate-scale-in flex items-center gap-2 ${
          toast.type === 'success' ? 'bg-emerald-500 text-white' :
          toast.type === 'error' ? 'bg-red-500 text-white' :
          'bg-purple-500 text-white'
        }`}>
          {toast.type === 'success' && <Check className="w-5 h-5" />}
          {toast.type === 'error' && <AlertCircle className="w-5 h-5" />}
          {toast.type === 'info' && <Lightbulb className="w-5 h-5" />}
          <span className="text-sm font-medium">{toast.message}</span>
        </div>
      )}

      <div className="glass-card rounded-2xl p-6 animate-fade-in-up">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-14 h-14 rounded-2xl gradient-bg flex items-center justify-center shadow-soft-lg">
            <FlaskConical className="w-7 h-7 text-white icon-glow" />
          </div>
          <div>
            <h2 className="text-2xl font-display font-bold gradient-text">科研工作台</h2>
            <p className="text-purple-500 text-sm">本周（第 {currentWeek} 周）新增 {thisWeekPapers.length} 篇前沿文献</p>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'gradient-bg text-white shadow-soft-lg scale-105'
                    : 'bg-purple-50/80 text-purple-600 hover:bg-purple-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {activeTab === 'papers' && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <h3 className="text-lg font-semibold text-purple-800 font-display">
              文献库 · 共 {papers.length} 篇
            </h3>
            <div className="flex gap-2 flex-wrap">
              <div className="relative">
                <Search className="w-4 h-4 text-purple-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="搜索文献..."
                  className="pl-9 pr-4 py-2 bg-purple-50 text-purple-700 rounded-xl text-sm border border-purple-100 focus:outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-200 transition-all w-48"
                />
              </div>
              <button 
                onClick={() => setShowBatchImport(true)}
                className="flex items-center gap-2 px-4 py-2 bg-purple-50 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-100 transition-colors"
              >
                <Upload className="w-4 h-4" />
                批量导入
              </button>
              <button
                onClick={() => setShowAddPaper(true)}
                className="flex items-center gap-2 px-4 py-2 gradient-btn text-white rounded-xl text-sm font-medium"
              >
                <Plus className="w-4 h-4" />
                添加文献
              </button>
            </div>
          </div>

          <div className="glass-card rounded-2xl p-4 flex items-center gap-4 bg-gradient-to-r from-lavender-50/50 to-purple-50/50">
            <LinkIcon className="w-5 h-5 text-lavender-500 flex-shrink-0" />
            <p className="text-sm text-purple-600 flex-1">
              支持从 PubMed、Google Scholar 一键同步文献，或批量导入文献数据
            </p>
            <button 
              onClick={() => showToast('数据库连接功能开发中，敬请期待！', 'info')}
              className="px-4 py-2 bg-white/80 text-lavender-600 rounded-xl text-sm font-medium hover:bg-white transition-colors flex-shrink-0"
            >
              连接数据库
            </button>
          </div>

          <div className="space-y-4">
            {filteredPapers.map((paper, index) => (
              <div
                key={paper.id}
                className={`glass-card glass-card-hover rounded-2xl p-6 animate-fade-in-up stagger-${(index % 4) + 1}`}
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <h4 className="font-semibold text-purple-800 flex-1 text-base leading-snug">{paper.title}</h4>
                  <span className="text-xs text-purple-400 whitespace-nowrap flex-shrink-0">
                    {formatDate(paper.date)}
                  </span>
                </div>
                <p className="text-sm text-purple-500 mb-2">{paper.authors}</p>
                <div className="flex items-center gap-2 text-xs text-mint-600 mb-3">
                  <BookOpen className="w-4 h-4" />
                  {paper.journal}
                </div>
                <p className="text-sm text-purple-600 mb-4 bg-purple-50/50 p-3 rounded-xl leading-relaxed">
                  {paper.abstract}
                </p>
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    {paper.tags.map((tag) => (
                      <span
                        key={tag}
                        className="flex items-center gap-1 px-3 py-1 bg-lavender-100/80 text-lavender-600 rounded-full text-xs"
                      >
                        <Tag className="w-3 h-3" />
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowMindMap(paper.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 text-purple-600 rounded-lg text-xs font-medium hover:bg-purple-100 transition-colors"
                    >
                      <GitBranch className="w-3.5 h-3.5" />
                      思维导图
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {filteredPapers.length === 0 && (
              <div className="glass-card rounded-2xl p-12 text-center">
                <BookOpen className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                <p className="text-purple-500">暂无匹配的文献</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'ai' && (
        <div className="glass-card rounded-2xl overflow-hidden animate-fade-in-up">
          <div className="p-4 border-b border-purple-100/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full gradient-bg flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-purple-800">AI 实验助手</h3>
                <p className="text-xs text-mint-500 flex items-center gap-1">
                  <span className="w-2 h-2 bg-mint-400 rounded-full animate-pulse" />
                  在线，随时为你解答实验问题
                </p>
              </div>
            </div>
            <button 
              onClick={handleClearChat}
              className="flex items-center gap-1 px-3 py-1.5 bg-purple-50 text-purple-500 rounded-lg text-xs font-medium hover:bg-purple-100 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              清空对话
            </button>
          </div>

          <div className="h-96 overflow-y-auto p-4 space-y-4 scrollbar-thin">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    msg.role === 'user'
                      ? 'bg-purple-100'
                      : 'gradient-bg'
                  }`}
                >
                  {msg.role === 'user' ? (
                    <User className="w-4 h-4 text-purple-600" />
                  ) : (
                    <Bot className="w-4 h-4 text-white" />
                  )}
                </div>
                <div
                  className={`max-w-[80%] p-4 rounded-2xl ${
                    msg.role === 'user'
                      ? 'gradient-bg text-white rounded-tr-md'
                      : 'bg-purple-50/80 text-purple-700 rounded-tl-md'
                  }`}
                >
                  <p className="text-sm whitespace-pre-line leading-relaxed">{msg.content}</p>
                </div>
              </div>
            ))}
            {isChatLoading && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full gradient-bg flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-purple-50/80 p-4 rounded-2xl rounded-tl-md">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 text-purple-500 animate-spin" />
                    <span className="text-sm text-purple-500">正在思考中...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {chatMessages.length <= 1 && (
            <div className="px-4 pb-2">
              <p className="text-xs text-purple-400 mb-2 flex items-center gap-1">
                <Lightbulb className="w-3 h-3" />
                快速提问：
              </p>
              <div className="flex flex-wrap gap-2">
                {quickQuestions.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => handleQuickQuestion(q)}
                    className="px-3 py-1.5 bg-purple-50 text-purple-600 rounded-full text-xs hover:bg-purple-100 transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="p-4 border-t border-purple-100/50">
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="输入你的实验问题..."
                className="flex-1 px-4 py-3 rounded-xl bg-purple-50/80 border border-purple-100/50 focus:outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-200 transition-all text-purple-700 placeholder-purple-400"
                disabled={isChatLoading}
              />
              <button
                onClick={handleSend}
                disabled={isChatLoading || !input.trim()}
                className="gradient-btn px-6 py-3 rounded-xl text-white flex items-center gap-2 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4" />
                发送
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'notes' && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <h3 className="text-lg font-semibold text-purple-800 font-display">
              实验周报 · 第 {currentWeek} 周
            </h3>
            <div className="flex gap-2">
              <button 
                onClick={handleGenerateWeeklyReport}
                className="flex items-center gap-2 px-4 py-2 bg-purple-50 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-100 transition-colors"
              >
                <FileTextIcon className="w-4 h-4" />
                生成本周周报
              </button>
              <button
                onClick={() => setShowAddNote(true)}
                className="flex items-center gap-2 px-4 py-2 gradient-btn text-white rounded-xl text-sm font-medium"
              >
                <Plus className="w-4 h-4" />
                新建记录
              </button>
            </div>
          </div>

          <div className="glass-card rounded-2xl p-4 bg-gradient-to-r from-pink-50/50 to-purple-50/50">
            <p className="text-sm text-purple-600">
              💡 提示：实验记录会自动按周归档，支持标签筛选和搜索，方便回溯查找
            </p>
          </div>

          <div className="space-y-4">
            {experimentNotes.map((note, index) => (
              <div
                key={note.id}
                className={`glass-card glass-card-hover rounded-2xl p-6 animate-fade-in-up stagger-${(index % 4) + 1}`}
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <h4 className="font-semibold text-purple-800">{note.title}</h4>
                  <div className="flex items-center gap-2 text-xs text-purple-400 whitespace-nowrap flex-shrink-0">
                    <Clock className="w-3 h-3" />
                    {formatDate(note.date)}
                  </div>
                </div>
                <p className="text-sm text-purple-600 mb-4 leading-relaxed">{note.content}</p>
                <div className="flex gap-2 flex-wrap">
                  {note.tags.map((tag) => (
                    <span
                      key={tag}
                      className="flex items-center gap-1 px-3 py-1 bg-pink-100/80 text-pink-600 rounded-full text-xs"
                    >
                      <Tag className="w-3 h-3" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
            {experimentNotes.length === 0 && (
              <div className="glass-card rounded-2xl p-12 text-center">
                <Calendar className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                <p className="text-purple-500">暂无实验记录</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'ppt' && (
        <div className="glass-card rounded-2xl p-8 text-center animate-fade-in-up">
          <div className="w-20 h-20 rounded-3xl gradient-bg flex items-center justify-center mx-auto mb-6 shadow-soft-lg">
            <Sparkles className="w-10 h-10 text-white icon-glow" />
          </div>
          <h3 className="text-xl font-display font-bold gradient-text mb-2">
            文献汇报 PPT 生成
          </h3>
          <p className="text-purple-500 mb-6 max-w-md mx-auto">
            自动生成精选文献的汇报 PPT，含思维导图逻辑框架和模拟演讲稿
          </p>

          {pptData ? (
            <div className="max-w-md mx-auto mb-6 p-5 bg-mint-50 rounded-2xl border border-mint-200">
              <div className="flex items-center gap-3 mb-4">
                <CheckCircle2 className="w-8 h-8 text-mint-500 flex-shrink-0" />
                <div className="text-left flex-1">
                  <p className="font-medium text-mint-700">PPT 生成完成！</p>
                  <p className="text-xs text-mint-600">包含 {pptData.paperCount} 篇文献，共 {pptData.slides.length} 页</p>
                  <p className="text-xs text-mint-500 mt-0.5">生成日期：{pptData.generatedDate}</p>
                </div>
              </div>
              <div className="flex gap-2 mb-2">
                <button 
                  onClick={() => { setCurrentSlideIndex(0); setShowPPTViewer(true); }}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-mint-500 text-white rounded-xl text-sm font-medium hover:bg-mint-600 transition-colors"
                >
                  <Eye className="w-4 h-4" />
                  查看 PPT
                </button>
                <button 
                  onClick={handleDownloadPPT}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-white text-mint-600 rounded-xl text-sm font-medium border border-mint-200 hover:bg-mint-50 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  下载 PPT
                </button>
              </div>
              <button 
                onClick={() => setShowSpeechModal(true)}
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-mint-50 text-mint-600 rounded-xl text-sm font-medium border border-mint-100 hover:bg-mint-100 transition-colors"
              >
                <FileTextIcon className="w-4 h-4" />
                查看演讲稿
              </button>
            </div>
          ) : isGeneratingPPT ? (
            <div className="max-w-md mx-auto mb-6 p-5 bg-purple-50 rounded-2xl">
              <div className="flex items-center justify-center gap-3 mb-3">
                <Loader2 className="w-6 h-6 text-lavender-500 animate-spin" />
                <p className="text-purple-700 font-medium">正在生成 PPT...</p>
              </div>
              <div className="h-2 bg-purple-200 rounded-full overflow-hidden">
                <div className="h-full gradient-bg rounded-full animate-pulse" style={{ width: '65%' }} />
              </div>
              <p className="text-xs text-purple-500 mt-2">正在整理文献内容和思维导图框架...</p>
            </div>
          ) : null}

          {!pptData && !isGeneratingPPT && (
            <button
              onClick={handleGeneratePPT}
              className="inline-flex items-center gap-2 px-6 py-3 gradient-btn text-white rounded-xl cursor-pointer"
            >
              <FileText className="w-5 h-5" />
              生成最新汇报 PPT
            </button>
          )}

          {pptData && (
            <div className="mt-4">
              <button
                onClick={handleGeneratePPT}
                disabled={isGeneratingPPT}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm text-purple-500 hover:text-purple-700 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isGeneratingPPT ? 'animate-spin' : ''}`} />
                重新生成
              </button>
            </div>
          )}

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            <div className="p-4 bg-purple-50/50 rounded-xl">
              <p className="text-2xl font-display font-bold gradient-text">3-4篇</p>
              <p className="text-xs text-purple-500 mt-1">精选文献</p>
            </div>
            <div className="p-4 bg-pink-50/50 rounded-xl">
              <p className="text-2xl font-display font-bold gradient-text">8+页</p>
              <p className="text-xs text-purple-500 mt-1">精美PPT</p>
            </div>
            <div className="p-4 bg-mint-50/50 rounded-xl">
              <p className="text-2xl font-display font-bold gradient-text">思维导图</p>
              <p className="text-xs text-purple-500 mt-1">逻辑框架</p>
            </div>
          </div>

          <p className="text-xs text-purple-400 mt-6">
            PPT 包含：封面页、提纲页、文献详情页、逻辑框架页、总结页
          </p>
        </div>
      )}

      {showAddPaper && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowAddPaper(false)}>
          <div className="glass-card rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scale-in" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-purple-100/50 flex items-center justify-between sticky top-0 bg-white/80 backdrop-blur z-10">
              <h3 className="font-semibold text-purple-800 text-lg">添加文献</h3>
              <button onClick={() => setShowAddPaper(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
                <X className="w-5 h-5 text-purple-500" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm text-purple-600 mb-1 block">标题 *</label>
                <input
                  type="text"
                  value={newPaper.title}
                  onChange={e => setNewPaper({ ...newPaper, title: e.target.value })}
                  placeholder="输入文献标题"
                  className="w-full px-4 py-3 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-purple-600 mb-1 block">作者</label>
                  <input
                    type="text"
                    value={newPaper.authors}
                    onChange={e => setNewPaper({ ...newPaper, authors: e.target.value })}
                    placeholder="作者列表"
                    className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm"
                  />
                </div>
                <div>
                  <label className="text-sm text-purple-600 mb-1 block">期刊</label>
                  <input
                    type="text"
                    value={newPaper.journal}
                    onChange={e => setNewPaper({ ...newPaper, journal: e.target.value })}
                    placeholder="期刊名称"
                    className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">发表日期</label>
                <input
                  type="date"
                  value={newPaper.date}
                  onChange={e => setNewPaper({ ...newPaper, date: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 text-sm"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">摘要</label>
                <textarea
                  value={newPaper.abstract}
                  onChange={e => setNewPaper({ ...newPaper, abstract: e.target.value })}
                  placeholder="输入文献摘要..."
                  rows={4}
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm resize-none"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">标签（用逗号分隔）</label>
                <input
                  type="text"
                  value={newPaper.tags}
                  onChange={e => setNewPaper({ ...newPaper, tags: e.target.value })}
                  placeholder="例如：点击化学, 蛋白质标记, 活体成像"
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowAddPaper(false)}
                  className="flex-1 py-3 bg-purple-100 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-200 transition-colors"
                >
                  取消
                </button>
                <button
                  onClick={handleAddPaper}
                  className="flex-1 py-3 gradient-btn text-white rounded-xl text-sm font-medium"
                >
                  添加
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showAddNote && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowAddNote(false)}>
          <div className="glass-card rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scale-in" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-purple-100/50 flex items-center justify-between sticky top-0 bg-white/80 backdrop-blur z-10">
              <h3 className="font-semibold text-purple-800 text-lg">新建实验记录</h3>
              <button onClick={() => setShowAddNote(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
                <X className="w-5 h-5 text-purple-500" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm text-purple-600 mb-1 block">实验标题 *</label>
                <input
                  type="text"
                  value={newNote.title}
                  onChange={e => setNewNote({ ...newNote, title: e.target.value })}
                  placeholder="输入实验标题"
                  className="w-full px-4 py-3 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">日期</label>
                <input
                  type="date"
                  value={newNote.date}
                  onChange={e => setNewNote({ ...newNote, date: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 text-sm"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">实验内容</label>
                <textarea
                  value={newNote.content}
                  onChange={e => setNewNote({ ...newNote, content: e.target.value })}
                  placeholder="记录实验过程、结果、心得..."
                  rows={6}
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm resize-none"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">标签（用逗号分隔）</label>
                <input
                  type="text"
                  value={newNote.tags}
                  onChange={e => setNewNote({ ...newNote, tags: e.target.value })}
                  placeholder="例如：WB, 细胞实验, 点击化学"
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowAddNote(false)}
                  className="flex-1 py-3 bg-purple-100 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-200 transition-colors"
                >
                  取消
                </button>
                <button
                  onClick={handleAddNote}
                  className="flex-1 py-3 gradient-btn text-white rounded-xl text-sm font-medium"
                >
                  保存
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showBatchImport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowBatchImport(false)}>
          <div className="glass-card rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scale-in" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-purple-100/50 flex items-center justify-between sticky top-0 bg-white/80 backdrop-blur z-10">
              <h3 className="font-semibold text-purple-800 text-lg">批量导入文献</h3>
              <button onClick={() => setShowBatchImport(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
                <X className="w-5 h-5 text-purple-500" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              {importSuccess !== null ? (
                <div className="text-center py-8">
                  <CheckCircle2 className="w-16 h-16 text-mint-500 mx-auto mb-4" />
                  <p className="text-lg font-semibold text-mint-700">导入成功！</p>
                  <p className="text-sm text-mint-600 mt-1">共导入 {importSuccess} 篇文献</p>
                </div>
              ) : (
                <>
                  <div>
                    <label className="text-sm text-purple-600 mb-2 block flex items-center gap-2">
                      <FileTextIcon className="w-4 h-4" />
                      批量导入格式说明
                    </label>
                    <div className="bg-purple-50/80 rounded-xl p-3 border border-purple-100">
                      <p className="text-xs text-purple-500 mb-2">
                        每行一篇文献，用 <code className="bg-white px-1.5 py-0.5 rounded text-purple-600 font-mono">|</code> 分隔字段：
                      </p>
                      <p className="text-xs text-purple-600 font-mono">
                        标题|作者|期刊|日期|摘要|标签1,标签2
                      </p>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-purple-600 mb-1 block">文献数据</label>
                    <textarea
                      value={batchImportText}
                      onChange={e => setBatchImportText(e.target.value)}
                      placeholder={`示例：\nTetrazine Bioorthogonal Chemistry|Robinson CJ, et al.|Nature Chemical Biology|2025-03-12|研究开发了...|四嗪化学,体内成像\nPhotoinducible Bioorthogonal Reactions|Zhang X, et al.|JACS|2024-11-20|报道了...|光控反应,蛋白质功能`}
                      rows={10}
                      className="w-full px-4 py-3 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm resize-none font-mono"
                    />
                  </div>
                  <div className="flex gap-3 pt-2">
                    <button
                      onClick={() => setShowBatchImport(false)}
                      className="flex-1 py-3 bg-purple-100 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-200 transition-colors"
                    >
                      取消
                    </button>
                    <button
                      onClick={handleBatchImport}
                      className="flex-1 py-3 gradient-btn text-white rounded-xl text-sm font-medium"
                    >
                      导入
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {showPPTViewer && pptData && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setShowPPTViewer(false)}>
          <div className="glass-card rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden animate-scale-in flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="p-4 border-b border-purple-100/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-purple-800 text-sm">{pptData.title}</h3>
                  <p className="text-xs text-purple-500">
                    第 {currentSlideIndex + 1} / {pptData.slides.length} 页
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadPPT}
                  className="flex items-center gap-1 px-3 py-1.5 bg-purple-50 text-purple-600 rounded-lg text-xs font-medium hover:bg-purple-100 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  下载
                </button>
                <button onClick={() => setShowPPTViewer(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
                  <X className="w-5 h-5 text-purple-500" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-hidden bg-gray-900">
              <div className={`w-full h-full flex items-center justify-center p-8 ${
                pptData.slides[currentSlideIndex]?.type === 'title' 
                  ? 'bg-gradient-to-br from-purple-600 to-pink-600' 
                  : pptData.slides[currentSlideIndex]?.type === 'summary'
                  ? 'bg-gradient-to-br from-emerald-500 to-blue-500'
                  : pptData.slides[currentSlideIndex]?.type === 'mindmap'
                  ? 'bg-gradient-to-br from-indigo-500 to-purple-600'
                  : 'bg-white'
              }`}>
                <div className="max-w-2xl w-full">
                  {pptData.slides[currentSlideIndex]?.type === 'title' ? (
                    <div className="text-center text-white">
                      <h1 className="text-4xl font-bold mb-6">{pptData.slides[currentSlideIndex]?.title}</h1>
                      <p className="text-lg whitespace-pre-line opacity-90 leading-relaxed">
                        {pptData.slides[currentSlideIndex]?.content}
                      </p>
                    </div>
                  ) : pptData.slides[currentSlideIndex]?.type === 'summary' ? (
                    <div className="text-white">
                      <h2 className="text-3xl font-bold mb-6">{pptData.slides[currentSlideIndex]?.title}</h2>
                      <p className="text-base whitespace-pre-line opacity-95 leading-relaxed">
                        {pptData.slides[currentSlideIndex]?.content}
                      </p>
                    </div>
                  ) : pptData.slides[currentSlideIndex]?.type === 'mindmap' ? (
                    <div className="text-white">
                      <h2 className="text-2xl font-bold mb-6 text-center">{pptData.slides[currentSlideIndex]?.title}</h2>
                      <p className="text-sm whitespace-pre-line opacity-95 leading-relaxed font-mono">
                        {pptData.slides[currentSlideIndex]?.content}
                      </p>
                    </div>
                  ) : (
                    <div>
                      <h2 className="text-2xl font-bold text-purple-700 mb-6 pb-4 border-b-2 border-purple-500">
                        {pptData.slides[currentSlideIndex]?.title}
                      </h2>
                      <p className="text-gray-700 whitespace-pre-line leading-relaxed">
                        {pptData.slides[currentSlideIndex]?.content}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="p-4 border-t border-purple-100/50 flex items-center justify-between bg-white">
              <button
                onClick={() => setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1))}
                disabled={currentSlideIndex === 0}
                className="flex items-center gap-1 px-4 py-2 bg-purple-50 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4" />
                上一页
              </button>
              <div className="flex gap-1.5">
                {pptData.slides.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentSlideIndex(i)}
                    className={`w-2.5 h-2.5 rounded-full transition-all ${
                      i === currentSlideIndex ? 'bg-purple-500 w-6' : 'bg-purple-200 hover:bg-purple-300'
                    }`}
                  />
                ))}
              </div>
              <button
                onClick={() => setCurrentSlideIndex(Math.min(pptData.slides.length - 1, currentSlideIndex + 1))}
                disabled={currentSlideIndex === pptData.slides.length - 1}
                className="flex items-center gap-1 px-4 py-2 bg-purple-50 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                下一页
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {showSpeechModal && pptData && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowSpeechModal(false)}>
          <div className="glass-card rounded-3xl w-full max-w-2xl max-h-[80vh] overflow-hidden animate-scale-in flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-purple-100/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center">
                  <FileTextIcon className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-purple-800">演讲稿</h3>
                  <p className="text-xs text-purple-500">{pptData.title}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadSpeech}
                  className="flex items-center gap-1 px-3 py-1.5 bg-purple-50 text-purple-600 rounded-lg text-xs font-medium hover:bg-purple-100 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  下载
                </button>
                <button onClick={() => setShowSpeechModal(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
                  <X className="w-5 h-5 text-purple-500" />
                </button>
              </div>
            </div>
            <div className="p-6 overflow-auto flex-1">
              <div className="prose prose-sm max-w-none">
                <p className="text-purple-700 whitespace-pre-line leading-relaxed text-sm">
                  {pptData.speech}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {showMindMap && <MindMapComponent paperId={showMindMap} />}
    </div>
  );
}
