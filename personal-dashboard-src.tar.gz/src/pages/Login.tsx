import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Mail,
  Lock,
  User,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Copy,
  Check,
  Inbox,
} from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';

type Mode = 'login' | 'register';

export default function Login() {
  const navigate = useNavigate();
  const { login, register, isLoggedIn, isEmailRegistered, sendVerificationCode, verifyCode } = useAuthStore();

  const [mode, setMode] = useState<Mode>('login');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [nickname, setNickname] = useState('');
  const [countdown, setCountdown] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [currentCode, setCurrentCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    if (isLoggedIn) {
      navigate('/');
    }
  }, [isLoggedIn, navigate]);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const validateEmail = (value: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  };

  const handleSendCode = async () => {
    setError('');
    setSuccess('');

    if (!validateEmail(email)) {
      setError('请输入正确的邮箱地址');
      return;
    }

    if (mode === 'login' && !isEmailRegistered(email)) {
      setError('该邮箱未注册，请先注册');
      return;
    }

    if (mode === 'register' && isEmailRegistered(email)) {
      setError('该邮箱已注册，请直接登录');
      return;
    }

    setIsSending(true);
    await new Promise((resolve) => setTimeout(resolve, 800));

    const generatedCode = sendVerificationCode(email);
    setCurrentCode(generatedCode);
    setIsSending(false);
    setCountdown(60);
    setSuccess('验证码已发送，请查收邮件');
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async () => {
    setError('');
    setSuccess('');

    if (!validateEmail(email)) {
      setError('请输入正确的邮箱地址');
      return;
    }

    if (code.length !== 6) {
      setError('请输入6位验证码');
      return;
    }

    if (!verifyCode(email, code)) {
      setError('验证码错误或已过期');
      return;
    }

    if (mode === 'register') {
      if (!nickname.trim()) {
        setError('请输入昵称');
        return;
      }
      const result = await register(email, nickname.trim());
      if (result) {
        setSuccess('注册成功，正在进入...');
        setTimeout(() => navigate('/'), 1000);
      } else {
        setError('注册失败，请重试');
      }
    } else {
      const result = await login(email);
      if (result) {
        setSuccess('登录成功，正在进入...');
        setTimeout(() => navigate('/'), 1000);
      } else {
        setError('登录失败，请重试');
      }
    }
  };

  const switchMode = (newMode: Mode) => {
    setMode(newMode);
    setError('');
    setSuccess('');
    setCode('');
    setCurrentCode('');
    setCountdown(0);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-purple-100 via-pink-50 to-lavender-100">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-64 h-64 bg-purple-300/30 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-pink-300/30 rounded-full blur-3xl animate-float-delay" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-lavender-300/20 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="glass-card rounded-3xl p-8 shadow-2xl animate-scale-in">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl gradient-bg flex items-center justify-center mx-auto mb-4 shadow-glow-soft">
              <Sparkles className="w-8 h-8 text-white icon-glow" />
            </div>
            <h1 className="text-2xl font-display font-bold gradient-text mb-2">
              {mode === 'login' ? '欢迎回来' : '创建账号'}
            </h1>
            <p className="text-purple-500 text-sm">
              {mode === 'login'
                ? '登录您的个人工作台'
                : '开启您的个性化之旅'}
            </p>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-pink-50 border border-pink-200 rounded-xl flex items-center gap-2 animate-shake">
              <AlertCircle className="w-5 h-5 text-pink-500 flex-shrink-0" />
              <span className="text-sm text-pink-600">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 bg-mint-50 border border-mint-200 rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-mint-500 flex-shrink-0" />
              <span className="text-sm text-mint-600">{success}</span>
            </div>
          )}

          {currentCode && (
            <div className="mb-4 p-4 bg-purple-50 border border-purple-200 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Inbox className="w-5 h-5 text-purple-500" />
                <span className="text-sm font-medium text-purple-700">模拟邮箱验证码</span>
              </div>
              <div className="flex items-center justify-between bg-white rounded-lg p-3 border border-purple-100">
                <span className="text-2xl font-bold gradient-text tracking-widest">{currentCode}</span>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 px-3 py-1.5 text-sm text-purple-500 hover:text-lavender-500 hover:bg-purple-50 rounded-lg transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4" />
                      已复制
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      复制
                    </>
                  )}
                </button>
              </div>
              <p className="text-xs text-purple-400 mt-2">
                演示模式：验证码已生成验证码，10分钟内有效
              </p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="text-sm text-purple-600 mb-2 block">邮箱</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value.trim())}
                  placeholder="请输入邮箱地址"
                  className="w-full pl-12 pr-4 py-3 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-200 transition-all text-purple-700 placeholder-purple-400"
                />
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="text-sm text-purple-600 mb-2 block">昵称</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
                  <input
                    type="text"
                    value={nickname}
                    onChange={(e) => setNickname(e.target.value)}
                    placeholder="请输入昵称"
                    maxLength={20}
                    className="w-full pl-12 pr-4 py-3 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-200 transition-all text-purple-700 placeholder-purple-400"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-sm text-purple-600 mb-2 block">验证码</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
                <input
                  type={showCode ? 'text' : 'password'}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="请输入6位验证码"
                  className="w-full pl-12 pr-24 py-3 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 focus:ring-2 focus:ring-lavender-200 transition-all text-purple-700 placeholder-purple-400 tracking-widest"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  <button
                    onClick={() => setShowCode(!showCode)}
                    className="p-2 hover:bg-purple-100 rounded-lg transition-colors"
                  >
                    {showCode ? (
                      <EyeOff className="w-4 h-4 text-purple-400" />
                    ) : (
                      <Eye className="w-4 h-4 text-purple-400" />
                    )}
                  </button>
                  <button
                    onClick={handleSendCode}
                    disabled={countdown > 0 || isSending}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                      countdown > 0 || isSending
                        ? 'bg-purple-100 text-purple-400 cursor-not-allowed'
                        : 'gradient-bg text-white hover:shadow-soft'
                    }`}
                  >
                    {isSending ? '发送中...' : countdown > 0 ? `${countdown}s` : '获取验证码'}
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={handleSubmit}
              className="w-full py-3.5 gradient-btn text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:shadow-soft-lg transition-all duration-300 group"
            >
              {mode === 'login' ? '登录' : '注册并登录'}
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm text-purple-500">
              {mode === 'login' ? '还没有账号？' : '已有账号？'}
              <button
                onClick={() => switchMode(mode === 'login' ? 'register' : 'login')}
                className="text-lavender-500 hover:text-lavender-600 font-medium ml-1"
              >
                {mode === 'login' ? '立即注册' : '立即登录'}
              </button>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t border-purple-100/50">
            <p className="text-xs text-center text-purple-400">
              演示模式说明：验证码会显示在页面上方
              <br />
              数据存储在本地浏览器中
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
