import { useState, useEffect } from 'react';
import {
  BookOpen,
  BarChart3,
  ListFilter,
  Star,
  BookMarked,
  TrendingUp,
  Clock,
  Award,
  RefreshCw,
  Plus,
  X,
  Link as LinkIcon,
  Trash2,
  Tag,
  Settings,
  Check,
  Zap,
  Target,
  Sparkles,
  Loader2,
  ChevronRight,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { useReadingStore } from '../store/useReadingStore';
import type { Book } from '../types';
import type { RecommendedBook } from '../store/useReadingStore';

type TabType = 'shelf' | 'stats' | 'recommendations';

export default function Reading() {
  const [activeTab, setActiveTab] = useState<TabType>('shelf');
  const {
    books,
    stats,
    customTags,
    wechatSync,
    recommendedBooks,
    addBook,
    updateBookStatus,
    deleteBook,
    toggleReread,
    clearAllData,
    connectWechat,
    disconnectWechat,
    startWechatSync,
    generateRecommendations,
    addRecommendedBookToShelf,
  } = useReadingStore();
  const [filter, setFilter] = useState<'all' | 'reading' | 'finished' | 'want-to-read'>('all');
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const [showAddBook, setShowAddBook] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showWeChatSync, setShowWeChatSync] = useState(false);
  const [selectedBook, setSelectedBook] = useState<string | null>(null);

  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    cover: '',
    status: 'want-to-read' as Book['status'],
    isPhysical: false,
    rating: 0,
    tags: '',
  });

  useEffect(() => {
    generateRecommendations();
  }, [books]);

  const handleConnectWechat = async () => {
    await connectWechat();
  };

  const handleStartSync = async () => {
    await startWechatSync();
  };

  const tabs = [
    { id: 'shelf', label: '我的书架', icon: BookOpen },
    { id: 'stats', label: '阅读分析', icon: BarChart3 },
    { id: 'recommendations', label: '书单推荐', icon: Award },
  ];

  let filteredBooks = books.filter((b) => filter === 'all' || b.status === filter);
  if (tagFilter) {
    filteredBooks = filteredBooks.filter((b) => b.tags.includes(tagFilter));
  }

  const categoryData = Object.entries(stats.categories).map(([name, value]) => ({
    name,
    value,
  }));

  const COLORS = ['#A78BFA', '#F472B6', '#2DD4BF', '#FBBF24', '#60A5FA'];

  const renderStars = (rating: number, interactive = false, onRate?: (r: number) => void) => {
    return (
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            onClick={() => interactive && onRate?.(star)}
            className={`w-4 h-4 ${star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-purple-200'} ${interactive ? 'cursor-pointer hover:scale-110 transition-transform' : ''}`}
          />
        ))}
      </div>
    );
  };

  const statusLabels: Record<string, string> = {
    reading: '在读',
    finished: '已读完',
    'want-to-read': '想读',
  };

  const allTags = [...new Set(books.flatMap((b) => b.tags))];

  const handleAddBook = () => {
    if (!newBook.title.trim()) return;
    addBook({
      title: newBook.title,
      author: newBook.author,
      cover: newBook.cover || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=300&h=400&fit=crop',
      rating: newBook.rating,
      status: newBook.status,
      isPhysical: newBook.isPhysical,
      needReread: false,
      tags: newBook.tags.split(/[,，]/).map((t) => t.trim()).filter(Boolean),
    });
    setNewBook({ title: '', author: '', cover: '', status: 'want-to-read', isPhysical: false, rating: 0, tags: '' });
    setShowAddBook(false);
  };

  const WeChatSyncModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowWeChatSync(false)}>
      <div className="glass-card rounded-3xl w-full max-w-md animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <div className="p-6 border-b border-purple-100/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center">
              <LinkIcon className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold text-purple-800 text-lg">微信读书同步</h3>
          </div>
          <button onClick={() => setShowWeChatSync(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
            <X className="w-5 h-5 text-purple-500" />
          </button>
        </div>
        <div className="p-6 space-y-5">
          <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-purple-700">连接状态</p>
              <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${wechatSync.connected ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                {wechatSync.connected ? <Check className="w-3 h-3" /> : null}
                {wechatSync.connected ? '已连接' : '未连接'}
              </span>
            </div>
            {wechatSync.lastSyncTime && (
              <p className="text-xs text-purple-500">上次同步：{wechatSync.lastSyncTime}</p>
            )}
            {wechatSync.syncedBookCount > 0 && (
              <p className="text-xs text-purple-500 mt-1">已同步书籍：{wechatSync.syncedBookCount} 本</p>
            )}
          </div>

          {wechatSync.connected && (
            <div className="space-y-2">
              <p className="text-sm font-medium text-purple-700">同步内容</p>
              {wechatSync.steps.map((step, index) => (
                <div
                  key={step.key}
                  className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                    step.completed
                      ? 'bg-green-50'
                      : step.inProgress
                      ? 'bg-purple-50'
                      : 'bg-gray-50'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                      step.completed
                        ? 'bg-green-500 text-white'
                        : step.inProgress
                        ? 'bg-purple-500 text-white'
                        : 'bg-gray-200 text-gray-400'
                    }`}
                  >
                    {step.completed ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : step.inProgress ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <span className="text-xs font-medium">{index + 1}</span>
                    )}
                  </div>
                  <span
                    className={`text-sm ${
                      step.completed
                        ? 'text-green-600'
                        : step.inProgress
                        ? 'text-purple-700 font-medium'
                        : 'text-gray-400'
                    }`}
                  >
                    {step.label}
                  </span>
                </div>
              ))}
            </div>
          )}

          {wechatSync.syncing && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-purple-600">{wechatSync.currentStep}</span>
                <span className="text-sm font-medium text-lavender-600">{wechatSync.progress}%</span>
              </div>
              <div className="w-full h-2 bg-purple-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-green-400 to-emerald-500 transition-all duration-300 rounded-full"
                  style={{ width: `${wechatSync.progress}%` }}
                />
              </div>
            </div>
          )}

          {!wechatSync.connected ? (
            <button
              onClick={handleConnectWechat}
              disabled={wechatSync.connecting}
              className="w-full py-3 bg-gradient-to-r from-green-400 to-emerald-500 text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {wechatSync.connecting ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> 连接中...</>
              ) : (
                <><Zap className="w-4 h-4" /> 模拟连接微信读书</>
              )}
            </button>
          ) : (
            <div className="space-y-3">
              <button
                onClick={handleStartSync}
                disabled={wechatSync.syncing}
                className="w-full py-3 bg-gradient-to-r from-green-400 to-emerald-500 text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {wechatSync.syncing ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> 同步中...</>
                ) : (
                  <><RefreshCw className="w-4 h-4" /> 立即同步</>
                )}
              </button>
              <button
                onClick={() => {
                  if (confirm('确定要断开微信读书连接吗？')) {
                    disconnectWechat();
                  }
                }}
                disabled={wechatSync.syncing || wechatSync.connecting}
                className="w-full py-3 bg-red-50 text-red-500 rounded-xl text-sm font-medium hover:bg-red-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                断开连接
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const SettingsModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowSettings(false)}>
      <div className="glass-card rounded-3xl w-full max-w-md animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <div className="p-6 border-b border-purple-100/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold text-purple-800 text-lg">读书设置</h3>
          </div>
          <button onClick={() => setShowSettings(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
            <X className="w-5 h-5 text-purple-500" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <p className="text-sm font-medium text-purple-700 mb-2">自定义标签</p>
            <div className="flex flex-wrap gap-2 mb-3">
              {customTags.map((tag) => (
                <span
                  key={tag}
                  className="flex items-center gap-1 px-3 py-1 bg-lavender-100/80 text-lavender-600 rounded-full text-xs"
                >
                  <Tag className="w-3 h-3" />
                  {tag}
                </span>
              ))}
            </div>
            <p className="text-xs text-purple-400">在添加书籍时可使用这些标签</p>
          </div>
          <div className="pt-4 border-t border-purple-100/50">
            <p className="text-sm font-medium text-purple-700 mb-3">数据管理</p>
            <button
              onClick={() => {
                if (confirm('确定要清空所有读书数据吗？此操作不可恢复。')) {
                  clearAllData();
                  setShowSettings(false);
                }
              }}
              className="w-full flex items-center justify-center gap-2 py-3 bg-red-50 text-red-500 rounded-xl text-sm font-medium hover:bg-red-100 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              清空所有数据
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const finishedCount = books.filter((b) => b.status === 'finished').length;
  const readingCount = books.filter((b) => b.status === 'reading').length;
  const wantToReadCount = books.filter((b) => b.status === 'want-to-read').length;
  const totalPages = books.reduce((sum, b) => sum + (b.progress || 0), 0);

  return (
    <div className="space-y-6">
      <div className="glass-card rounded-2xl p-6 animate-fade-in-up">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-400 to-purple-400 flex items-center justify-center shadow-soft-lg">
            <BookOpen className="w-7 h-7 text-white icon-glow" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-display font-bold gradient-text">读书空间</h2>
            <p className="text-purple-500 text-sm">共 {books.length} 本书 · 已读 {finishedCount} 本 · 在读 {readingCount} 本</p>
          </div>
          <button
            onClick={() => setShowSettings(true)}
            className="p-2.5 hover:bg-purple-100 rounded-xl transition-colors"
          >
            <Settings className="w-5 h-5 text-purple-500" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <div className="p-3 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl text-center">
            <p className="text-xl font-display font-bold gradient-text">{books.length}</p>
            <p className="text-xs text-purple-500">总书籍</p>
          </div>
          <div className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl text-center">
            <p className="text-xl font-display font-bold text-green-600">{finishedCount}</p>
            <p className="text-xs text-purple-500">已读完</p>
          </div>
          <div className="p-3 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl text-center">
            <p className="text-xl font-display font-bold text-cyan-600">{readingCount}</p>
            <p className="text-xs text-purple-500">在读</p>
          </div>
          <div className="p-3 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl text-center">
            <p className="text-xl font-display font-bold text-orange-500">{wantToReadCount}</p>
            <p className="text-xs text-purple-500">想读</p>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all duration-300 ${activeTab === tab.id
                    ? 'gradient-bg text-white shadow-soft-lg scale-105'
                    : 'bg-purple-50/80 text-purple-600 hover:bg-purple-100 hover:scale-102'
                  }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {activeTab === 'shelf' && (
        <div className="space-y-6">
          <div className="glass-card rounded-2xl p-5 bg-gradient-to-r from-green-50/50 to-emerald-50/50 animate-fade-in-up">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center flex-shrink-0 shadow-lg shadow-green-200">
                <LinkIcon className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-semibold text-purple-800">微信读书同步</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${wechatSync.connected ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                    {wechatSync.connected ? '已连接' : '未连接'}
                  </span>
                </div>
                <p className="text-xs text-purple-500">
                  {wechatSync.connected
                    ? wechatSync.syncing
                      ? wechatSync.currentStep
                      : `上次同步：${wechatSync.lastSyncTime || '刚刚'}`
                    : '一键同步你的阅读进度和书架'}
                </p>
              </div>
              <button
                onClick={() => setShowWeChatSync(true)}
                className="flex items-center gap-1 px-4 py-2 bg-white/80 text-green-600 rounded-xl text-sm font-medium hover:bg-white hover:shadow-md transition-all"
              >
                {wechatSync.connected ? (
                  <><RefreshCw className={`w-4 h-4 ${wechatSync.syncing ? 'animate-spin' : ''}`} /> 同步</>
                ) : (
                  <>去连接 <ChevronRight className="w-4 h-4" /></>
                )}
              </button>
            </div>
            {wechatSync.syncing && (
              <div className="mt-4">
                <div className="w-full h-1.5 bg-green-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-green-400 to-emerald-500 transition-all duration-500 rounded-full"
                    style={{ width: `${wechatSync.progress}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex gap-2 flex-wrap">
              {(['all', 'reading', 'finished', 'want-to-read'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${filter === f
                      ? 'bg-lavender-100 text-lavender-700'
                      : 'text-purple-500 hover:bg-purple-50/80'
                    }`}
                >
                  <ListFilter className="w-4 h-4" />
                  {statusLabels[f] || '全部'}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowAddBook(true)}
                className="flex items-center gap-2 px-4 py-2 gradient-btn text-white rounded-xl text-sm font-medium"
              >
                <Plus className="w-4 h-4" />
                添加书籍
              </button>
            </div>
          </div>

          {allTags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setTagFilter(null)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${!tagFilter
                    ? 'gradient-bg text-white'
                    : 'bg-purple-50 text-purple-500 hover:bg-purple-100'
                  }`}
              >
                全部标签
              </button>
              {allTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setTagFilter(tagFilter === tag ? null : tag)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${tagFilter === tag
                      ? 'gradient-bg text-white'
                      : 'bg-lavender-100/80 text-lavender-600 hover:bg-lavender-200'
                    }`}
                >
                  <Tag className="w-3 h-3" />
                  {tag}
                </button>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredBooks.map((book, index) => (
              <div
                key={book.id}
                className={`glass-card glass-card-hover rounded-2xl overflow-hidden animate-fade-in-up stagger-${(index % 4) + 1}`}
              >
                <div
                  className="relative h-48 overflow-hidden cursor-pointer"
                  onClick={() => setSelectedBook(selectedBook === book.id ? null : book.id)}
                >
                  <img
                    src={book.cover}
                    alt={book.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${book.status === 'reading'
                        ? 'bg-mint-400/90 text-white'
                        : book.status === 'finished'
                          ? 'bg-lavender-400/90 text-white'
                          : 'bg-pink-400/90 text-white'
                      }`}>
                      {statusLabels[book.status]}
                    </span>
                  </div>
                  {book.status === 'reading' && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-purple-100">
                      <div
                        className="h-full gradient-bg transition-all duration-500"
                        style={{ width: `${book.progress}%` }}
                      />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h4 className="font-semibold text-purple-800 mb-1 line-clamp-1">
                    {book.title}
                  </h4>
                  <p className="text-sm text-purple-500 mb-3">{book.author}</p>
                  <div className="flex items-center justify-between">
                    {renderStars(book.rating)}
                    <div className="flex items-center gap-1">
                      {book.needReread && (
                        <RefreshCw className="w-4 h-4 text-pink-400" />
                      )}
                      {book.isPhysical && (
                        <span className="text-xs text-purple-400">📚</span>
                      )}
                    </div>
                  </div>
                </div>

                {selectedBook === book.id && (
                  <div className="p-4 border-t border-purple-100/50 space-y-3 animate-fade-in">
                    <div className="flex flex-wrap gap-1">
                      {book.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-0.5 bg-purple-50 text-purple-500 rounded text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => updateBookStatus(book.id, 'reading')}
                        className={`py-2 text-xs rounded-lg transition-colors ${book.status === 'reading'
                            ? 'bg-mint-100 text-mint-600'
                            : 'bg-purple-50 text-purple-500 hover:bg-purple-100'
                          }`}
                      >
                        在读
                      </button>
                      <button
                        onClick={() => updateBookStatus(book.id, 'finished')}
                        className={`py-2 text-xs rounded-lg transition-colors ${book.status === 'finished'
                            ? 'bg-lavender-100 text-lavender-600'
                            : 'bg-purple-50 text-purple-500 hover:bg-purple-100'
                          }`}
                      >
                        读完
                      </button>
                      <button
                        onClick={() => updateBookStatus(book.id, 'want-to-read')}
                        className={`py-2 text-xs rounded-lg transition-colors ${book.status === 'want-to-read'
                            ? 'bg-pink-100 text-pink-600'
                            : 'bg-purple-50 text-purple-500 hover:bg-purple-100'
                          }`}
                      >
                        想读
                      </button>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => toggleReread(book.id)}
                        className={`flex-1 flex items-center justify-center gap-1 py-2 text-xs rounded-lg transition-colors ${book.needReread
                            ? 'bg-pink-100 text-pink-600'
                            : 'bg-purple-50 text-purple-500 hover:bg-purple-100'
                          }`}
                      >
                        <RefreshCw className="w-3 h-3" />
                        {book.needReread ? '已标记重读' : '标记重读'}
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('确定要删除这本书吗？')) {
                            deleteBook(book.id);
                            setSelectedBook(null);
                          }
                        }}
                        className="flex items-center justify-center gap-1 px-3 py-2 text-xs rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                        删除
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'stats' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="glass-card rounded-2xl p-6 animate-fade-in-up">
            <h3 className="font-semibold text-purple-800 mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-lavender-500" />
              本周阅读时长
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.dailyMinutes}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E9D5FF" />
                  <XAxis dataKey="day" stroke="#A78BFA" fontSize={12} />
                  <YAxis stroke="#A78BFA" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255,255,255,0.9)',
                      border: '1px solid #E9D5FF',
                      borderRadius: '12px',
                    }}
                  />
                  <Bar dataKey="minutes" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
                  <defs>
                    <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#A78BFA" />
                      <stop offset="100%" stopColor="#C4B5FD" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass-card rounded-2xl p-6 animate-fade-in-up stagger-2">
            <h3 className="font-semibold text-purple-800 mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-pink-500" />
              分类占比
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255,255,255,0.9)',
                      border: '1px solid #E9D5FF',
                      borderRadius: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap gap-3 justify-center">
              {categoryData.map((item, index) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="text-xs text-purple-600">{item.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card rounded-2xl p-6 lg:col-span-2 animate-fade-in-up stagger-3">
            <h3 className="font-semibold text-purple-800 mb-6">本周数据概览</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-purple-50/80 rounded-2xl">
                <BookOpen className="w-8 h-8 text-lavender-500 mx-auto mb-2" />
                <p className="text-2xl font-display font-bold gradient-text">{stats.booksRead}</p>
                <p className="text-xs text-purple-500">本周读完</p>
              </div>
              <div className="text-center p-4 bg-pink-50/80 rounded-2xl">
                <Clock className="w-8 h-8 text-pink-400 mx-auto mb-2" />
                <p className="text-2xl font-display font-bold gradient-text">{stats.totalMinutes}</p>
                <p className="text-xs text-purple-500">分钟</p>
              </div>
              <div className="text-center p-4 bg-mint-50/80 rounded-2xl">
                <TrendingUp className="w-8 h-8 text-mint-400 mx-auto mb-2" />
                <p className="text-2xl font-display font-bold gradient-text">+15%</p>
                <p className="text-xs text-purple-500">较上周</p>
              </div>
              <div className="text-center p-4 bg-lavender-50/80 rounded-2xl">
                <Award className="w-8 h-8 text-lavender-500 mx-auto mb-2" />
                <p className="text-2xl font-display font-bold gradient-text">连续</p>
                <p className="text-xs text-purple-500">阅读 12 天</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'recommendations' && (
        <div className="space-y-6">
          <div className="glass-card rounded-2xl p-6 bg-gradient-to-br from-yellow-50/50 to-orange-50/50 animate-fade-in-up">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-400 flex items-center justify-center shadow-lg shadow-yellow-200">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-display font-bold gradient-text mb-1">
                  智能书单推荐
                </h3>
                <p className="text-purple-500 text-sm">
                  基于你的阅读偏好和历史评分，AI为你精选了 {recommendedBooks.length} 本好书
                </p>
              </div>
              <button
                onClick={generateRecommendations}
                className="flex items-center gap-1 px-4 py-2 bg-white/80 text-orange-500 rounded-xl text-sm font-medium hover:bg-white hover:shadow-md transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                刷新推荐
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendedBooks.map((book: RecommendedBook, index: number) => (
              <div
                key={book.id}
                className={`glass-card glass-card-hover rounded-2xl overflow-hidden animate-fade-in-up stagger-${(index % 4) + 1}`}
              >
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={book.cover}
                    alt={book.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-purple-900/70 via-purple-900/20 to-transparent" />
                  <div className="absolute top-3 right-3">
                    <div className="flex items-center gap-1 px-2 py-1 bg-white/90 backdrop-blur-sm rounded-full">
                      <Target className="w-3 h-3 text-orange-500" />
                      <span className="text-xs font-semibold text-orange-600">{book.matchScore}%</span>
                    </div>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h4 className="font-semibold text-white mb-1 line-clamp-1">{book.title}</h4>
                    <p className="text-sm text-purple-200">{book.author}</p>
                  </div>
                </div>
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-3.5 h-3.5 ${star <= book.rating ? 'fill-yellow-400 text-yellow-400' : 'text-purple-200'}`}
                        />
                      ))}
                    </div>
                    {book.isPhysical && <span className="text-xs text-purple-400">📚 纸质书</span>}
                  </div>
                  <p className="text-sm text-purple-600 line-clamp-2 min-h-[2.5rem]">
                    {book.recommendationReason}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {book.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 bg-lavender-100/60 text-lavender-600 rounded text-xs"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={() => addRecommendedBookToShelf(book.id)}
                    className="w-full gradient-btn py-2.5 rounded-xl text-white text-sm font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    加入书架
                  </button>
                </div>
              </div>
            ))}
          </div>

          {recommendedBooks.length === 0 && (
            <div className="glass-card rounded-2xl p-12 text-center animate-fade-in-up">
              <BookMarked className="w-16 h-16 text-purple-300 mx-auto mb-4" />
              <h4 className="text-lg font-semibold text-purple-700 mb-2">暂无推荐</h4>
              <p className="text-purple-500 text-sm mb-4">添加更多书籍到你的书架，获取更精准的推荐</p>
              <button
                onClick={generateRecommendations}
                className="px-6 py-2 gradient-btn text-white rounded-xl text-sm font-medium"
              >
                重新生成推荐
              </button>
            </div>
          )}
        </div>
      )}

      {showAddBook && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowAddBook(false)}>
          <div className="glass-card rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b border-purple-100/50 flex items-center justify-between">
              <h3 className="font-semibold text-purple-800 text-lg">添加书籍</h3>
              <button onClick={() => setShowAddBook(false)} className="p-2 hover:bg-purple-100 rounded-xl transition-colors">
                <X className="w-5 h-5 text-purple-500" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm text-purple-600 mb-1 block">书名 *</label>
                <input
                  type="text"
                  value={newBook.title}
                  onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                  placeholder="输入书名"
                  className="w-full px-4 py-3 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">作者</label>
                <input
                  type="text"
                  value={newBook.author}
                  onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                  placeholder="作者名称"
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">封面图片链接</label>
                <input
                  type="text"
                  value={newBook.cover}
                  onChange={(e) => setNewBook({ ...newBook, cover: e.target.value })}
                  placeholder="https://..."
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm"
                />
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-2 block">阅读状态</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['want-to-read', 'reading', 'finished'] as const).map((status) => (
                    <button
                      key={status}
                      onClick={() => setNewBook({ ...newBook, status })}
                      className={`py-2 text-sm rounded-xl transition-all ${newBook.status === status
                          ? 'gradient-bg text-white'
                          : 'bg-purple-50 text-purple-500 hover:bg-purple-100'
                        }`}
                    >
                      {statusLabels[status]}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newBook.isPhysical}
                    onChange={(e) => setNewBook({ ...newBook, isPhysical: e.target.checked })}
                    className="w-4 h-4 text-lavender-500 rounded focus:ring-lavender-400"
                  />
                  <span className="text-sm text-purple-600">纸质书</span>
                </label>
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-2 block">评分</label>
                {renderStars(newBook.rating, true, (r) => setNewBook({ ...newBook, rating: r }))}
              </div>
              <div>
                <label className="text-sm text-purple-600 mb-1 block">标签（用逗号分隔）</label>
                <input
                  type="text"
                  value={newBook.tags}
                  onChange={(e) => setNewBook({ ...newBook, tags: e.target.value })}
                  placeholder="例如：心理学, 自我提升"
                  className="w-full px-4 py-2 rounded-xl bg-purple-50/80 border border-purple-100 focus:outline-none focus:border-lavender-400 transition-all text-purple-700 placeholder-purple-400 text-sm"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setShowAddBook(false)}
                  className="flex-1 py-3 bg-purple-100 text-purple-600 rounded-xl text-sm font-medium hover:bg-purple-200 transition-colors"
                >
                  取消
                </button>
                <button
                  onClick={handleAddBook}
                  className="flex-1 py-3 gradient-btn text-white rounded-xl text-sm font-medium"
                >
                  添加
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showWeChatSync && <WeChatSyncModal />}
      {showSettings && <SettingsModal />}
    </div>
  );
}
