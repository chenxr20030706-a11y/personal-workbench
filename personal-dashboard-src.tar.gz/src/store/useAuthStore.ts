import { create } from 'zustand';
import { storage } from '../utils/storage';
import { generateId } from '../utils/date';

export interface User {
  id: string;
  email: string;
  nickname: string;
  avatar: string;
  createdAt: string;
  lastLoginAt: string;
}

interface VerificationCode {
  code: string;
  email: string;
  expiresAt: string;
}

interface AuthState {
  isLoggedIn: boolean;
  currentUser: User | null;
  users: User[];
  verificationCode: VerificationCode | null;
  login: (email: string) => Promise<boolean>;
  register: (email: string, nickname: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
  isEmailRegistered: (email: string) => boolean;
  sendVerificationCode: (email: string) => string;
  verifyCode: (email: string, code: string) => boolean;
  clearVerificationCode: () => void;
}

const STORAGE_KEY_USERS = 'auth-users';
const STORAGE_KEY_CURRENT = 'auth-current';
const STORAGE_KEY_CODE = 'auth-verification-code';

const generateVerificationCode = (): string => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

export const useAuthStore = create<AuthState>((set, get) => ({
  isLoggedIn: !!storage.get<User | null>(STORAGE_KEY_CURRENT, null),
  currentUser: storage.get<User | null>(STORAGE_KEY_CURRENT, null),
  users: storage.get<User[]>(STORAGE_KEY_USERS, []),
  verificationCode: storage.get<VerificationCode | null>(STORAGE_KEY_CODE, null),

  login: async (email) => {
    const users = get().users;
    const user = users.find((u) => u.email === email);
    
    if (!user) {
      return false;
    }

    const updatedUser = { ...user, lastLoginAt: new Date().toISOString() };
    const updatedUsers = users.map((u) => (u.id === user.id ? updatedUser : u));
    
    storage.set(STORAGE_KEY_USERS, updatedUsers);
    storage.set(STORAGE_KEY_CURRENT, updatedUser);
    storage.remove(STORAGE_KEY_CODE);
    
    set({
      isLoggedIn: true,
      currentUser: updatedUser,
      users: updatedUsers,
      verificationCode: null,
    });
    
    return true;
  },

  register: async (email, nickname) => {
    const users = get().users;
    
    if (users.some((u) => u.email === email)) {
      return false;
    }

    const newUser: User = {
      id: generateId(),
      email,
      nickname,
      avatar: nickname.charAt(0).toUpperCase(),
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };

    const updatedUsers = [...users, newUser];
    storage.set(STORAGE_KEY_USERS, updatedUsers);
    storage.set(STORAGE_KEY_CURRENT, newUser);
    storage.remove(STORAGE_KEY_CODE);
    
    set({
      isLoggedIn: true,
      currentUser: newUser,
      users: updatedUsers,
      verificationCode: null,
    });
    
    return true;
  },

  logout: () => {
    storage.remove(STORAGE_KEY_CURRENT);
    storage.remove(STORAGE_KEY_CODE);
    set({
      isLoggedIn: false,
      currentUser: null,
      verificationCode: null,
    });
  },

  updateProfile: (updates) => {
    const { currentUser, users } = get();
    if (!currentUser) return;

    const updatedUser = { ...currentUser, ...updates };
    const updatedUsers = users.map((u) => (u.id === currentUser.id ? updatedUser : u));
    
    storage.set(STORAGE_KEY_USERS, updatedUsers);
    storage.set(STORAGE_KEY_CURRENT, updatedUser);
    
    set({
      currentUser: updatedUser,
      users: updatedUsers,
    });
  },

  isEmailRegistered: (email) => {
    return get().users.some((u) => u.email === email);
  },

  sendVerificationCode: (email) => {
    const code = generateVerificationCode();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    
    const verificationCode: VerificationCode = { code, email, expiresAt };
    storage.set(STORAGE_KEY_CODE, verificationCode);
    
    set({ verificationCode });
    return code;
  },

  verifyCode: (email, code) => {
    const stored = get().verificationCode;
    if (!stored) return false;
    if (stored.email !== email) return false;
    if (stored.code !== code) return false;
    if (new Date(stored.expiresAt) < new Date()) return false;
    return true;
  },

  clearVerificationCode: () => {
    storage.remove(STORAGE_KEY_CODE);
    set({ verificationCode: null });
  },
}));
