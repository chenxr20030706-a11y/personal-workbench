import { create } from 'zustand';
import type { Paper, ExperimentNote, ChatMessage } from '../types';
import { mockPapers, mockExperimentNotes, initialChatMessages } from '../data/mockData';
import { storage } from '../utils/storage';
import { generateId, getWeekNumber, getTodayStr } from '../utils/date';

export interface MindMapNode {
  id: string;
  label: string;
  children?: MindMapNode[];
  color?: string;
  x?: number;
  y?: number;
}

export interface PPTSlide {
  id: string;
  title: string;
  content: string;
  type: 'title' | 'content' | 'summary' | 'mindmap';
}

export interface PPTData {
  id: string;
  title: string;
  generatedDate: string;
  slides: PPTSlide[];
  speech: string;
  paperCount: number;
}

interface ResearchState {
  papers: Paper[];
  experimentNotes: ExperimentNote[];
  chatMessages: ChatMessage[];
  isChatLoading: boolean;
  pptData: PPTData | null;
  isGeneratingPPT: boolean;
  addPaper: (paper: Omit<Paper, 'id' | 'week' | 'year'>) => void;
  addExperimentNote: (note: Omit<ExperimentNote, 'id' | 'week' | 'year'>) => void;
  addChatMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  sendMessage: (content: string) => void;
  clearChat: () => void;
  generateMindMap: (paperId: string) => MindMapNode;
  exportMindMap: (paperId: string, format: 'png' | 'json' | 'text') => void;
  generatePPT: () => Promise<void>;
  downloadPPT: () => void;
  downloadSpeech: () => void;
  generateWeeklyReport: () => string;
  batchImportPapers: (papers: Omit<Paper, 'id' | 'week' | 'year'>[]) => number;
}

const today = new Date();
const currentWeek = getWeekNumber(today);
const currentYear = today.getFullYear();

const STORAGE_KEY_PAPERS = 'research-papers';
const STORAGE_KEY_NOTES = 'research-notes';
const STORAGE_KEY_CHAT = 'research-chat';
const STORAGE_KEY_PPT = 'research-ppt';

const aiResponses: Record<string, string> = {
  default: '这是一个很好的问题！关于你的实验，我建议你可以从以下几个方面考虑：\n\n1. **对照组设置**：确保你的实验有合适的阴性对照和阳性对照\n2. **反应条件**：检查温度、pH值、反应时间等参数是否在最佳范围内\n3. **试剂质量**：确认所有试剂都是新鲜配制的，没有过期\n\n你可以告诉我更多实验细节，我可以给出更具体的建议。',
  'WB': '蛋白质印迹（Western Blot）实验常见问题及解决方案：\n\n**条带弥散**\n- 可能原因：蛋白降解、上样量过大、电泳条件不对\n- 解决方法：加入蛋白酶抑制剂、减少上样量、优化电泳时间\n\n**没有条带**\n- 可能原因：抗体不工作、浓度太低、转膜不充分\n- 解决方法：优化抗体稀释比例、检查转膜条件\n\n**背景太高**\n- 可能原因：一抗浓度太高、洗涤不充分\n- 解决方法：降低一抗稀释度、增加洗涤次数\n\n你遇到的是哪种情况？',
  '细胞': '细胞实验的注意事项：\n\n1. **无菌操作**：所有操作在生物安全柜内进行\n2. **细胞状态**：使用对数生长期细胞\n3. **传代次数**：避免传代次数过多\n4. **血清质量**：使用优质胎牛血清\n5. **污染检测**：定期检测支原体\n\n有什么具体问题我可以帮你解答吗？',
  'PCR': 'PCR实验优化建议：\n\n**引物设计**\n- 引物长度18-25bp，GC含量40-60%\n- 避免引物二聚体和发夹结构\n- Tm值差异不超过2℃\n\n**反应条件优化**\n- 退火温度：梯度PCR确定最佳温度\n- Mg2+浓度：1.5-2.5mM范围内优化\n- 循环数：25-35个循环\n\n**常见问题**\n- 非特异性条带：提高退火温度、减少引物量\n- 无产物：检查模板质量、优化引物浓度\n- 条带弱：增加循环数、优化模板量\n\n需要我帮你分析具体的实验方案吗？',
  '对照': '如何设计对照实验？\n\n**实验设计的基本原则**\n\n1. **阴性对照**\n- 空白对照：不加处理因素的对照组\n- 溶剂对照：使用溶剂处理的对照组\n- 假手术对照：仅手术不给处理\n\n2. **阳性对照**\n- 使用已知有效的处理方法\n- 验证实验体系的可靠性\n\n3. **对照设置的原则**\n- 唯一变量原则：除处理因素外其他条件一致\n- 平行重复原则：多次独立重复实验\n- 随机化原则：样本随机分组\n\n你的实验具体是什么类型？我可以帮你设计更具体的对照方案。',
  '污染': '细胞污染如何处理？\n\n**常见污染类型及处理**\n\n1. **细菌污染**\n- 表现：培养基浑浊、pH骤变\n- 处理：立即丢弃，检查无菌操作\n- 预防：定期检查培养基，规范操作\n\n2. **真菌污染**\n- 表现：显微镜下可见菌丝或孢子\n- 处理：丢弃，彻底消毒培养箱\n- 预防：保持环境干燥，定期清洁\n\n3. **支原体污染**\n- 表现：细胞生长缓慢、形态改变\n- 检测：PCR检测或荧光染色\n- 处理：使用支原体清除试剂或丢弃\n\n4. **预防措施**\n- 严格无菌操作\n- 定期检测细胞状态\n- 细胞株来源可靠\n- 试剂分装保存\n\n你现在遇到的是什么类型的污染？',
  '点击化学': '点击化学常见问题及解决方案：\n\n**CuAAC反应优化**\n\n1. **反应效率低**\n- 检查铜催化剂和配体比例（通常Cu:TBTA = 1:2）\n- 确保抗坏血酸钠新鲜配制\n- 反应体系pH保持在7-8之间\n\n2. **副反应多**\n- 降低铜离子浓度\n- 增加配体比例\n- 降低反应温度\n\n3. **蛋白沉淀**\n- 降低DMSO含量（<5%）\n- 使用温和的缓冲液\n- 优化反应时间\n\n**SPAAC反应特点**\n- 无需铜离子，生物相容性好\n- 反应速率相对较慢\n- 环辛炔试剂较贵\n\n你做的是哪种点击反应？遇到了什么具体问题？',
  '生物正交': '生物正交化学实验指导：\n\n**常用生物正交反应类型**\n\n1. **CuAAC（铜催化点击反应）**\n- 优点：反应快、产率高、试剂便宜\n- 缺点：铜离子有细胞毒性\n- 应用：体外标记、固定细胞\n\n2. **SPAAC（应变促进点击反应）**\n- 优点：无铜、生物相容性好\n- 缺点：反应较慢、试剂贵\n- 应用：活细胞、活体成像\n\n3. **四嗪/TCO反应**\n- 优点：反应极快、生物相容性好\n- 缺点：TCO可能不稳定\n- 应用：活体成像、药物递送\n\n4. **光点击反应**\n- 优点：时空可控\n- 缺点：需要光照设备\n- 应用：光控标记\n\n**实验设计建议**\n- 根据实验体系选择合适的反应类型\n- 设置阳性对照验证反应体系\n- 优化反应浓度和时间\n\n你具体想做哪方面的生物正交实验？',
};

const generateAIResponse = (content: string): string => {
  const lowerContent = content.toLowerCase();
  
  if (lowerContent.includes('wb') || lowerContent.includes('western') || lowerContent.includes('蛋白印迹') || lowerContent.includes('条带')) {
    return aiResponses['WB'];
  }
  if (lowerContent.includes('细胞') && lowerContent.includes('污染')) {
    return aiResponses['污染'];
  }
  if (lowerContent.includes('细胞')) {
    return aiResponses['细胞'];
  }
  if (lowerContent.includes('pcr') || lowerContent.includes('聚合酶')) {
    return aiResponses['PCR'];
  }
  if (lowerContent.includes('对照')) {
    return aiResponses['对照'];
  }
  if (lowerContent.includes('点击') || lowerContent.includes('cuacc') || lowerContent.includes('spaac')) {
    return aiResponses['点击化学'];
  }
  if (lowerContent.includes('生物正交')) {
    return aiResponses['生物正交'];
  }
  
  const keys = Object.keys(aiResponses).filter(k => k !== 'default');
  const randomKey = keys[Math.floor(Math.random() * keys.length)];
  return aiResponses[randomKey];
};

export const useResearchStore = create<ResearchState>((set, get) => ({
  papers: storage.get<Paper[]>(STORAGE_KEY_PAPERS, mockPapers),
  experimentNotes: storage.get<ExperimentNote[]>(STORAGE_KEY_NOTES, mockExperimentNotes),
  chatMessages: storage.get<ChatMessage[]>(STORAGE_KEY_CHAT, initialChatMessages),
  isChatLoading: false,
  pptData: storage.get<PPTData | null>(STORAGE_KEY_PPT, null),
  isGeneratingPPT: false,

  addPaper: (paper) => {
    const paperDate = new Date(paper.date || new Date());
    const newPaper: Paper = {
      ...paper,
      id: generateId(),
      week: getWeekNumber(paperDate),
      year: paperDate.getFullYear(),
    };
    set((state) => {
      const papers = [newPaper, ...state.papers];
      storage.set(STORAGE_KEY_PAPERS, papers);
      return { papers };
    });
  },

  addExperimentNote: (note) => {
    const noteDate = new Date(note.date || new Date());
    const newNote: ExperimentNote = {
      ...note,
      id: generateId(),
      week: getWeekNumber(noteDate),
      year: noteDate.getFullYear(),
    };
    set((state) => {
      const notes = [newNote, ...state.experimentNotes];
      storage.set(STORAGE_KEY_NOTES, notes);
      return { experimentNotes: notes };
    });
  },

  addChatMessage: (message) => {
    const newMessage: ChatMessage = {
      ...message,
      id: generateId(),
      timestamp: new Date().toISOString(),
    };
    set((state) => {
      const messages = [...state.chatMessages, newMessage];
      storage.set(STORAGE_KEY_CHAT, messages);
      return { chatMessages: messages };
    });
  },

  sendMessage: (content) => {
    const userMessage: ChatMessage = {
      id: generateId(),
      role: 'user',
      content,
      timestamp: new Date().toISOString(),
    };
    set((state) => {
      const messages = [...state.chatMessages, userMessage];
      storage.set(STORAGE_KEY_CHAT, messages);
      return { chatMessages: messages, isChatLoading: true };
    });

    setTimeout(() => {
      const response = generateAIResponse(content);
      const assistantMessage: ChatMessage = {
        id: generateId(),
        role: 'assistant',
        content: response,
        timestamp: new Date().toISOString(),
      };
      set((state) => {
        const messages = [...state.chatMessages, assistantMessage];
        storage.set(STORAGE_KEY_CHAT, messages);
        return { chatMessages: messages, isChatLoading: false };
      });
    }, 1200);
  },

  clearChat: () => {
    storage.set(STORAGE_KEY_CHAT, initialChatMessages);
    set({ chatMessages: initialChatMessages });
  },

  generateMindMap: (paperId: string): MindMapNode => {
    const paper = get().papers.find(p => p.id === paperId);
    if (!paper) {
      return { id: 'root', label: '未知文献' };
    }
    
    const tags = paper.tags || [];
    const tagNodes = tags.slice(0, 4).map((tag, i) => ({
      id: `tag-${i}`,
      label: tag,
      color: ['#A78BFA', '#F472B6', '#34D399', '#FB923C'][i % 4],
    }));

    return {
      id: 'root',
      label: paper.title.length > 50 ? paper.title.substring(0, 50) + '...' : paper.title,
      color: '#8B5CF6',
      children: [
        {
          id: 'background',
          label: '研究背景',
          color: '#A78BFA',
          children: [
            { id: 'bg1', label: '研究意义', color: '#C4B5FD' },
            { id: 'bg2', label: '研究现状', color: '#C4B5FD' },
            { id: 'bg3', label: '科学问题', color: '#C4B5FD' },
          ],
        },
        {
          id: 'methods',
          label: '实验方法',
          color: '#F472B6',
          children: [
            { id: 'm1', label: '实验设计', color: '#F9A8D4' },
            { id: 'm2', label: '材料试剂', color: '#F9A8D4' },
            { id: 'm3', label: '检测方法', color: '#F9A8D4' },
          ],
        },
        {
          id: 'findings',
          label: '关键发现',
          color: '#34D399',
          children: [
            { id: 'f1', label: '主要结果', color: '#6EE7B7' },
            { id: 'f2', label: '数据验证', color: '#6EE7B7' },
            { id: 'f3', label: '机制分析', color: '#6EE7B7' },
          ],
        },
        {
          id: 'conclusion',
          label: '结论展望',
          color: '#FB923C',
          children: [
            { id: 'c1', label: '研究结论', color: '#FDBA74' },
            { id: 'c2', label: '创新点', color: '#FDBA74' },
            { id: 'c3', label: '未来方向', color: '#FDBA74' },
          ],
        },
        {
          id: 'keywords',
          label: '关键词',
          color: '#60A5FA',
          children: tagNodes.length > 0 ? tagNodes : [
            { id: 'kw1', label: '生物正交', color: '#93C5FD' },
            { id: 'kw2', label: '点击化学', color: '#93C5FD' },
          ],
        },
      ],
    };
  },

  exportMindMap: (paperId: string, format: 'png' | 'json' | 'text') => {
    const paper = get().papers.find(p => p.id === paperId);
    if (!paper) return;

    const mindMap = get().generateMindMap(paperId);

    if (format === 'json') {
      const dataStr = JSON.stringify(mindMap, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${paper.title.replace(/\s+/g, '_').substring(0, 30)}_mindmap.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else if (format === 'text') {
      const generateText = (node: MindMapNode, level: number = 0): string => {
        let result = '  '.repeat(level) + '- ' + node.label + '\n';
        if (node.children) {
          node.children.forEach(child => {
            result += generateText(child, level + 1);
          });
        }
        return result;
      };
      const textContent = `思维导图：${paper.title}\n期刊：${paper.journal}\n作者：${paper.authors}\n\n${generateText(mindMap)}`;
      const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${paper.title.replace(/\s+/g, '_').substring(0, 30)}_mindmap.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else if (format === 'png') {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = 900;
      canvas.height = 650;

      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      gradient.addColorStop(0, '#FAF5FF');
      gradient.addColorStop(1, '#FDF2F8');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = 80;

      ctx.fillStyle = '#8B5CF6';
      ctx.fillRect(centerX - 180, centerY - 25, 360, 50);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 16px "Microsoft YaHei", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const title = paper.title.length > 35 ? paper.title.substring(0, 35) + '...' : paper.title;
      ctx.fillText(title, centerX, centerY);

      const branches = [
        { label: '研究背景', color: '#A78BFA', x: 150, y: 200, items: ['研究意义', '研究现状', '科学问题'] },
        { label: '实验方法', color: '#F472B6', x: 380, y: 200, items: ['实验设计', '材料试剂', '检测方法'] },
        { label: '关键发现', color: '#34D399', x: 520, y: 420, items: ['主要结果', '数据验证', '机制分析'] },
        { label: '结论展望', color: '#FB923C', x: 750, y: 200, items: ['研究结论', '创新点', '未来方向'] },
      ];

      branches.forEach(branch => {
        ctx.strokeStyle = branch.color;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY + 25);
        ctx.quadraticCurveTo(
          (centerX + branch.x) / 2,
          (centerY + branch.y) / 2 + 30,
          branch.x,
          branch.y - 20
        );
        ctx.stroke();

        ctx.fillStyle = branch.color;
        ctx.beginPath();
        ctx.arc(branch.x, branch.y - 20, 6, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = branch.color;
        ctx.font = 'bold 14px "Microsoft YaHei", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(branch.label, branch.x, branch.y + 10);

        ctx.font = '12px "Microsoft YaHei", sans-serif';
        ctx.fillStyle = '#4B5563';
        branch.items.forEach((item, i) => {
          const itemY = branch.y + 35 + i * 28;
          ctx.fillText(item, branch.x, itemY);
          
          ctx.strokeStyle = branch.color;
          ctx.lineWidth = 1;
          ctx.globalAlpha = 0.5;
          ctx.beginPath();
          ctx.moveTo(branch.x, branch.y + 20);
          ctx.lineTo(branch.x, itemY - 8);
          ctx.stroke();
          ctx.globalAlpha = 1;
        });
      });

      ctx.fillStyle = '#6B7280';
      ctx.font = '11px "Microsoft YaHei", sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(`${paper.journal} · ${paper.date}`, canvas.width - 20, canvas.height - 15);

      canvas.toBlob((blob) => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${paper.title.replace(/\s+/g, '_').substring(0, 30)}_mindmap.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      });
    }
  },

  generatePPT: async () => {
    set({ isGeneratingPPT: true });

    await new Promise(resolve => setTimeout(resolve, 2500));

    const papers = get().papers.slice(0, 4);
    
    const titleSlide: PPTSlide = {
      id: generateId(),
      title: '生物正交化学研究进展',
      content: `文献汇报\n\n汇报人：科研助手\n日期：${getTodayStr()}\n\n精选 ${papers.length} 篇最新研究文献`,
      type: 'title',
    };
    
    const outlineSlide: PPTSlide = {
      id: generateId(),
      title: '汇报提纲',
      content: `一、研究背景与意义\n   生物正交化学的发展历程与应用价值\n\n二、精选文献解读\n   1. 四嗪化学与体内免疫细胞成像\n   2. 光控生物正交反应与蛋白质操控\n   3. SPAAC反应的生物医学应用\n   4. 代谢糖标记与肿瘤转移研究\n\n三、总结与展望\n   领域发展趋势与未来研究方向`,
      type: 'content',
    };
    
    const contentSlides: PPTSlide[] = papers.map((paper, index) => ({
      id: generateId(),
      title: `文献 ${index + 1}：${paper.title}`,
      content: `作者：${paper.authors}\n期刊：${paper.journal}\n发表日期：${paper.date}\n\n摘要：\n${paper.abstract}\n\n关键词：${paper.tags.join('、')}`,
      type: 'content',
    }));
    
    const mindmapSlide: PPTSlide = {
      id: generateId(),
      title: '文献逻辑框架',
      content: `核心主题：生物正交化学研究进展\n\n├── 技术发展方向\n│   ├── 四嗪/TCO反应（高速、活体适用）\n│   ├── SPAAC反应（无铜、生物相容）\n│   ├── 光点击反应（时空可控）\n│   └── CuAAC反应（高效、体外适用）\n\n├── 主要应用领域\n│   ├── 活体成像（免疫细胞追踪）\n│   ├── 蛋白质组学（标记与鉴定）\n│   ├── 药物递送（ADC、前药激活）\n│   └── 糖生物学（代谢标记）\n\n└── 未来发展趋势\n    ├── 更高反应速率\n    ├── 更低生物毒性\n    ├── 多通道同时标记\n    └── 临床转化应用`,
      type: 'mindmap',
    };
    
    const summarySlide: PPTSlide = {
      id: generateId(),
      title: '总结与展望',
      content: `研究总结：\n\n• 四嗪化学推动了活体成像技术的发展\n• 光控反应实现了蛋白质功能的时空操控\n• SPAAC在药物递送领域展现巨大潜力\n• 代谢糖标记揭示了肿瘤转移新机制\n\n技术发展趋势：\n\n1. 反应动力学持续优化，向超快方向发展\n2. 生物相容性不断改善，减少细胞毒性\n3. 多色标记技术发展，实现多靶点同时成像\n4. 与其他技术（如CRISPR、超分辨成像）结合\n\n未来研究方向：\n\n• 开发新型生物正交反应对\n• 拓展在神经科学、免疫学等领域的应用\n• 推动临床诊断和治疗中的转化应用\n\n谢谢大家！`,
      type: 'summary',
    };
    
    const slides: PPTSlide[] = [
      titleSlide,
      outlineSlide,
      ...contentSlides,
      mindmapSlide,
      summarySlide,
    ];

    const speech = `各位老师同学，大家好！\n\n今天我将为大家汇报近期阅读的四篇关于生物正交化学的重要研究文献。生物正交化学作为化学生物学领域的核心技术，近年来发展迅速，在生命科学研究中发挥着越来越重要的作用。\n\n首先看第一篇文献，发表在Nature Chemical Biology上，研究主题是四嗪生物正交化学在免疫细胞体内成像中的应用。该研究利用四嗪与反式环辛烯的高速反应，结合代谢标记技术，实现了活体水平下免疫细胞迁移的高时空分辨率追踪。这项工作为研究免疫应答的动态过程提供了强大的工具。\n\n第二篇文献来自Journal of the American Chemical Society，报道了一种新型的光激活生物正交反应体系。研究人员利用邻甲基苯甲酰叠氮在紫外光照射下生成腈亚胺中间体的特性，结合遗传密码扩展技术，实现了活细胞内蛋白质活性的精确时空操控。这种光控策略为研究蛋白质的动态功能提供了新手段。\n\n第三篇是发表在Angewandte Chemie上的综述文章，系统总结了应变促进叠氮-炔烃环加成（SPAAC）反应的最新进展。文章详细讨论了环辛炔衍生物的设计策略、反应动力学优化，以及在糖生物学、蛋白质组学、药物递送等领域的广泛应用。\n\n第四篇文献来自Cell Chemical Biology，利用代谢糖标记技术结合定量蛋白质组学，研究了肿瘤转移过程中唾液酸化的动态变化。研究发现L1CAM的高唾液酸化与肿瘤侵袭能力密切相关，为肿瘤转移的早期诊断提供了新的生物标志物。\n\n总的来说，这四篇文献从不同角度展示了生物正交化学的快速发展和广阔应用前景。从反应类型的创新到应用领域的拓展，生物正交化学正在深刻改变生命科学的研究方式。未来，随着反应速率的提升、生物相容性的改善以及多色标记技术的发展，生物正交化学将在更多领域发挥重要作用。\n\n我的汇报到此结束，谢谢大家！`;

    const pptData: PPTData = {
      id: generateId(),
      title: '生物正交化学研究进展',
      generatedDate: getTodayStr(),
      slides,
      speech,
      paperCount: papers.length,
    };

    storage.set(STORAGE_KEY_PPT, pptData);
    set({ pptData, isGeneratingPPT: false });
  },

  downloadPPT: () => {
    const pptData = get().pptData;
    if (!pptData) return;

    let htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${pptData.title}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif; }
    .slide { 
      width: 100vw; 
      height: 100vh; 
      display: flex; 
      flex-direction: column; 
      justify-content: center; 
      align-items: center; 
      padding: 60px; 
      box-sizing: border-box; 
      page-break-after: always; 
    }
    .title-slide { 
      background: linear-gradient(135deg, #8B5CF6, #EC4899); 
      color: white; 
      text-align: center; 
    }
    .content-slide { 
      background: white; 
      color: #1F2937; 
      align-items: flex-start;
      justify-content: flex-start;
      padding-top: 80px;
    }
    .mindmap-slide {
      background: linear-gradient(135deg, #6366F1, #8B5CF6);
      color: white;
    }
    .summary-slide { 
      background: linear-gradient(135deg, #10B981, #3B82F6); 
      color: white; 
      align-items: flex-start;
      justify-content: flex-start;
      padding-top: 80px;
    }
    .title-slide h1 { font-size: 56px; margin-bottom: 40px; }
    .content-slide h2 { 
      font-size: 36px; 
      color: #8B5CF6; 
      margin-bottom: 30px; 
      text-align: left; 
      width: 100%;
      padding-bottom: 15px;
      border-bottom: 3px solid #8B5CF6;
    }
    .summary-slide h2 { 
      font-size: 42px; 
      margin-bottom: 40px; 
      text-align: left;
      width: 100%;
    }
    .mindmap-slide h2 {
      font-size: 42px;
      margin-bottom: 40px;
    }
    .content-text { 
      font-size: 22px; 
      line-height: 2; 
      white-space: pre-wrap; 
      text-align: left; 
      width: 100%; 
    }
    .summary-text { 
      font-size: 22px; 
      line-height: 2; 
      white-space: pre-wrap; 
      text-align: left;
      width: 100%;
    }
    .mindmap-text {
      font-size: 20px;
      line-height: 2.2;
      white-space: pre-wrap;
      font-family: 'Consolas', monospace;
    }
    .title-content {
      font-size: 28px;
      line-height: 1.8;
      opacity: 0.95;
    }
  </style>
</head>
<body>
`;

    pptData.slides.forEach(slide => {
      if (slide.type === 'title') {
        htmlContent += `<div class="slide title-slide"><h1>${slide.title}</h1><div class="title-content">${slide.content.replace(/\n/g, '<br>')}</div></div>\n`;
      } else if (slide.type === 'summary') {
        htmlContent += `<div class="slide summary-slide"><h2>${slide.title}</h2><div class="summary-text">${slide.content.replace(/\n/g, '<br>')}</div></div>\n`;
      } else if (slide.type === 'mindmap') {
        htmlContent += `<div class="slide mindmap-slide"><h2>${slide.title}</h2><div class="mindmap-text">${slide.content.replace(/\n/g, '<br>')}</div></div>\n`;
      } else {
        htmlContent += `<div class="slide content-slide"><h2>${slide.title}</h2><div class="content-text">${slide.content.replace(/\n/g, '<br>')}</div></div>\n`;
      }
    });

    htmlContent += `
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pptData.title.replace(/\s+/g, '_')}_PPT.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  downloadSpeech: () => {
    const pptData = get().pptData;
    if (!pptData) return;

    const blob = new Blob([pptData.speech], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pptData.title.replace(/\s+/g, '_')}_演讲稿.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  generateWeeklyReport: () => {
    const notes = get().experimentNotes.filter(n => n.week === currentWeek && n.year === currentYear);
    const papersThisWeek = get().papers.filter(p => p.week === currentWeek && p.year === currentYear);

    let report = `========================================\n`;
    report += `         实验周报 - 第${currentWeek}周\n`;
    report += `========================================\n`;
    report += `日期：${getTodayStr()}\n\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `  一、本周文献阅读（${papersThisWeek.length}篇）\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    papersThisWeek.forEach((paper, i) => {
      report += `  ${i + 1}. ${paper.title}\n`;
      report += `     作者：${paper.authors}\n`;
      report += `     期刊：${paper.journal}\n`;
      report += `     标签：${paper.tags.join('、')}\n\n`;
    });
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `  二、本周实验记录（${notes.length}条）\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    notes.forEach((note, i) => {
      report += `  ${i + 1}. ${note.title}（${note.date}）\n`;
      report += `     ${note.content}\n`;
      report += `     标签：${note.tags.join('、')}\n\n`;
    });
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    report += `  三、下周计划\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    report += `  1. 继续推进实验进度，完成当前系列实验\n`;
    report += `  2. 整理分析实验数据，绘制图表\n`;
    report += `  3. 阅读相关文献，拓展研究思路\n`;
    report += `  4. 准备组会汇报材料\n\n`;
    report += `========================================\n`;

    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `第${currentWeek}周实验周报.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    return report;
  },

  batchImportPapers: (papers) => {
    const newPapers = papers.map(paper => {
      const paperDate = new Date(paper.date || new Date());
      return {
        ...paper,
        id: generateId(),
        week: getWeekNumber(paperDate),
        year: paperDate.getFullYear(),
      };
    });
    set((state) => {
      const allPapers = [...newPapers, ...state.papers];
      storage.set(STORAGE_KEY_PAPERS, allPapers);
      return { papers: allPapers };
    });
    return newPapers.length;
  },
}));
