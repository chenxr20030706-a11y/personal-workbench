import { create } from 'zustand';
import type { Book, ReadingStats } from '../types';
import { mockBooks, mockReadingStats, wechatSyncBooks } from '../data/mockData';
import { storage } from '../utils/storage';
import { generateId, getTodayStr } from '../utils/date';

export interface RecommendedBook extends Book {
  recommendationReason: string;
  matchScore: number;
}

interface SyncStep {
  key: string;
  label: string;
  completed: boolean;
  inProgress: boolean;
}

interface WechatSyncState {
  connected: boolean;
  connecting: boolean;
  syncing: boolean;
  progress: number;
  currentStep: string;
  currentStepIndex: number;
  steps: SyncStep[];
  lastSyncTime?: string;
  syncedBookCount: number;
}

interface ReadingState {
  books: Book[];
  stats: ReadingStats;
  customTags: string[];
  wechatSync: WechatSyncState;
  recommendedBooks: RecommendedBook[];
  addBook: (book: Omit<Book, 'id' | 'thoughts' | 'progress'>) => void;
  updateBookProgress: (id: string, progress: number) => void;
  toggleReread: (id: string) => void;
  rateBook: (id: string, rating: number) => void;
  updateBookStatus: (id: string, status: Book['status']) => void;
  deleteBook: (id: string) => void;
  addCustomTag: (tag: string) => void;
  deleteCustomTag: (tag: string) => void;
  clearAllData: () => void;
  connectWechat: () => Promise<void>;
  disconnectWechat: () => void;
  startWechatSync: () => Promise<void>;
  generateRecommendations: () => void;
  addRecommendedBookToShelf: (bookId: string) => void;
}

const STORAGE_KEY_BOOKS = 'reading-books';
const STORAGE_KEY_STATS = 'reading-stats';
const STORAGE_KEY_TAGS = 'reading-tags';
const STORAGE_KEY_WECHAT = 'reading-wechat';

const defaultCustomTags = ['专业书', '心理学', '自我提升', '历史', '小说', '科幻', '哲学', '传记'];

const defaultSteps: SyncStep[] = [
  { key: 'shelf', label: '书架同步', completed: false, inProgress: false },
  { key: 'progress', label: '阅读进度同步', completed: false, inProgress: false },
  { key: 'notes', label: '笔记同步', completed: false, inProgress: false },
  { key: 'duration', label: '阅读时长同步', completed: false, inProgress: false },
];

const defaultWechatSync: WechatSyncState = {
  connected: false,
  connecting: false,
  syncing: false,
  progress: 0,
  currentStep: '',
  currentStepIndex: -1,
  steps: defaultSteps,
  syncedBookCount: 0,
};

const recommendedBooksPool: RecommendedBook[] = [
  {
    id: 'rec-1',
    title: '认知觉醒',
    author: '周岭',
    cover: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=300&h=400&fit=crop',
    rating: 5,
    status: 'want-to-read',
    isPhysical: false,
    needReread: false,
    tags: ['自我提升', '认知科学', '心理学'],
    thoughts: [],
    progress: 0,
    recommendationReason: '与你喜欢的「自我提升」和「心理学」主题高度匹配，帮助你提升认知能力',
    matchScore: 95,
  },
  {
    id: 'rec-2',
    title: '思考，快与慢',
    author: '丹尼尔·卡尼曼',
    cover: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=400&fit=crop',
    rating: 5,
    status: 'want-to-read',
    isPhysical: true,
    needReread: false,
    tags: ['心理学', '哲学', '思维方法'],
    thoughts: [],
    progress: 0,
    recommendationReason: '诺贝尔经济学奖得主经典著作，深入探讨人类思维的两个系统',
    matchScore: 92,
  },
  {
    id: 'rec-3',
    title: '化学简史',
    author: 'J.R.帕廷顿',
    cover: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=300&h=400&fit=crop',
    rating: 4,
    status: 'want-to-read',
    isPhysical: false,
    needReread: false,
    tags: ['化学', '历史', '专业书'],
    thoughts: [],
    progress: 0,
    recommendationReason: '基于你的化学专业背景，了解化学发展史有助于拓宽专业视野',
    matchScore: 88,
  },
  {
    id: 'rec-4',
    title: '当下的力量',
    author: '埃克哈特·托利',
    cover: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=400&fit=crop',
    rating: 5,
    status: 'want-to-read',
    isPhysical: false,
    needReread: false,
    tags: ['哲学', '心理学', '自我提升'],
    thoughts: [],
    progress: 0,
    recommendationReason: '与你读过的「被讨厌的勇气」有相似的哲学深度，帮助你活在当下',
    matchScore: 90,
  },
  {
    id: 'rec-5',
    title: '三体',
    author: '刘慈欣',
    cover: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=300&h=400&fit=crop',
    rating: 5,
    status: 'want-to-read',
    isPhysical: true,
    needReread: false,
    tags: ['科幻', '小说', '硬科幻'],
    thoughts: [],
    progress: 0,
    recommendationReason: '中国科幻巅峰之作，适合喜欢思考和探索的你',
    matchScore: 85,
  },
  {
    id: 'rec-6',
    title: '习惯的力量',
    author: '查尔斯·都希格',
    cover: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=300&h=400&fit=crop',
    rating: 4,
    status: 'want-to-read',
    isPhysical: false,
    needReread: false,
    tags: ['自我提升', '习惯养成', '心理学'],
    thoughts: [],
    progress: 0,
    recommendationReason: '你正在读「原子习惯」，这本书能帮你更深入理解习惯的底层逻辑',
    matchScore: 93,
  },
];

export const useReadingStore = create<ReadingState>((set, get) => ({
  books: storage.get<Book[]>(STORAGE_KEY_BOOKS, mockBooks),
  stats: storage.get<ReadingStats>(STORAGE_KEY_STATS, mockReadingStats),
  customTags: storage.get<string[]>(STORAGE_KEY_TAGS, defaultCustomTags),
  wechatSync: storage.get<WechatSyncState>(STORAGE_KEY_WECHAT, defaultWechatSync),
  recommendedBooks: [],

  addBook: (book) => {
    const todayStr = getTodayStr();
    const newBook: Book = {
      ...book,
      id: generateId(),
      thoughts: [],
      progress: book.status === 'finished' ? 100 : 0,
      startedDate: book.status === 'reading' || book.status === 'finished' ? todayStr : undefined,
      finishedDate: book.status === 'finished' ? todayStr : undefined,
    };
    set((state) => {
      const books = [newBook, ...state.books];
      storage.set(STORAGE_KEY_BOOKS, books);
      return { books };
    });
  },

  updateBookProgress: (id, progress) => {
    set((state) => {
      const books = state.books.map((b) =>
        b.id === id ? { ...b, progress, status: progress >= 100 ? 'finished' : b.status } : b
      );
      storage.set(STORAGE_KEY_BOOKS, books);
      return { books };
    });
  },

  toggleReread: (id) => {
    set((state) => {
      const books = state.books.map((b) =>
        b.id === id ? { ...b, needReread: !b.needReread } : b
      );
      storage.set(STORAGE_KEY_BOOKS, books);
      return { books };
    });
  },

  rateBook: (id, rating) => {
    set((state) => {
      const books = state.books.map((b) => (b.id === id ? { ...b, rating } : b));
      storage.set(STORAGE_KEY_BOOKS, books);
      return { books };
    });
  },

  updateBookStatus: (id, status) => {
    const todayStr = getTodayStr();
    set((state) => {
      const books = state.books.map((b) => {
        if (b.id !== id) return b;
        return {
          ...b,
          status,
          progress: status === 'finished' ? 100 : b.progress,
          finishedDate: status === 'finished' ? todayStr : undefined,
          startedDate: (status === 'reading' || status === 'finished') && !b.startedDate ? todayStr : b.startedDate,
        };
      });
      storage.set(STORAGE_KEY_BOOKS, books);
      return { books };
    });
  },

  deleteBook: (id) => {
    set((state) => {
      const books = state.books.filter((b) => b.id !== id);
      storage.set(STORAGE_KEY_BOOKS, books);
      return { books };
    });
  },

  addCustomTag: (tag) => {
    set((state) => {
      if (state.customTags.includes(tag)) return state;
      const customTags = [...state.customTags, tag];
      storage.set(STORAGE_KEY_TAGS, customTags);
      return { customTags };
    });
  },

  deleteCustomTag: (tag) => {
    set((state) => {
      const customTags = state.customTags.filter((t) => t !== tag);
      storage.set(STORAGE_KEY_TAGS, customTags);
      return { customTags };
    });
  },

  clearAllData: () => {
    storage.remove(STORAGE_KEY_BOOKS);
    storage.remove(STORAGE_KEY_STATS);
    storage.remove(STORAGE_KEY_TAGS);
    storage.remove(STORAGE_KEY_WECHAT);
    set({
      books: mockBooks,
      stats: mockReadingStats,
      customTags: defaultCustomTags,
      wechatSync: { ...defaultWechatSync, steps: [...defaultSteps] },
      recommendedBooks: [],
    });
  },

  connectWechat: async () => {
    set({ wechatSync: { ...get().wechatSync, connecting: true, currentStep: '正在连接微信读书...' } });
    await new Promise((resolve) => setTimeout(resolve, 1500));
    const newState: WechatSyncState = {
      connected: true,
      connecting: false,
      syncing: false,
      progress: 100,
      currentStep: '连接成功',
      currentStepIndex: -1,
      steps: defaultSteps,
      lastSyncTime: getTodayStr(),
      syncedBookCount: get().wechatSync.syncedBookCount,
    };
    set({ wechatSync: newState });
    storage.set(STORAGE_KEY_WECHAT, newState);
  },

  disconnectWechat: () => {
    set({ wechatSync: defaultWechatSync });
    storage.remove(STORAGE_KEY_WECHAT);
  },

  startWechatSync: async () => {
    const { wechatSync, books } = get();
    if (!wechatSync.connected) return;

    const stepConfigs = [
      { key: 'shelf', label: '正在同步书架信息...', progressStart: 0, progressEnd: 25 },
      { key: 'progress', label: '正在同步阅读进度...', progressStart: 25, progressEnd: 50 },
      { key: 'notes', label: '正在同步阅读笔记...', progressStart: 50, progressEnd: 75 },
      { key: 'duration', label: '正在同步阅读时长...', progressStart: 75, progressEnd: 100 },
    ];

    const newSteps = defaultSteps.map(s => ({ ...s, completed: false, inProgress: false }));

    set({
      wechatSync: {
        ...wechatSync,
        syncing: true,
        progress: 0,
        currentStep: stepConfigs[0].label,
        currentStepIndex: 0,
        steps: newSteps.map((s, i) => i === 0 ? { ...s, inProgress: true } : s),
      },
    });

    for (let i = 0; i < stepConfigs.length; i++) {
      const step = stepConfigs[i];
      const totalSteps = 10;
      for (let j = 1; j <= totalSteps; j++) {
        await new Promise((resolve) => setTimeout(resolve, 60));
        const progress = Math.round(step.progressStart + (step.progressEnd - step.progressStart) * (j / totalSteps));
        set((state) => ({
          wechatSync: {
            ...state.wechatSync,
            progress,
            currentStep: step.label,
          },
        }));
      }

      set((state) => ({
        wechatSync: {
          ...state.wechatSync,
          steps: state.wechatSync.steps.map((s, idx) => {
            if (idx === i) return { ...s, completed: true, inProgress: false };
            if (idx === i + 1) return { ...s, inProgress: true };
            return s;
          }),
          currentStepIndex: i + 1,
        },
      }));
    }

    const existingTitles = new Set(books.map((b) => b.title));
    const newBooks = wechatSyncBooks.filter(
      (b) => !existingTitles.has(b.title)
    ).map((book) => ({
      ...book,
      id: generateId(),
      thoughts: [...book.thoughts],
    }));

    if (newBooks.length > 0) {
      set((state) => {
        const updatedBooks = [...newBooks, ...state.books];
        storage.set(STORAGE_KEY_BOOKS, updatedBooks);
        return { books: updatedBooks };
      });
    }

    const finalState: WechatSyncState = {
      connected: true,
      connecting: false,
      syncing: false,
      progress: 100,
      currentStep: `同步完成，新增 ${newBooks.length} 本书`,
      currentStepIndex: -1,
      steps: newSteps.map(s => ({ ...s, completed: true, inProgress: false })),
      lastSyncTime: getTodayStr(),
      syncedBookCount: wechatSync.syncedBookCount + newBooks.length,
    };
    set({ wechatSync: finalState });
    storage.set(STORAGE_KEY_WECHAT, finalState);
  },

  generateRecommendations: () => {
    const { books } = get();

    const finishedBooks = books.filter((b) => b.status === 'finished');
    const readingBooks = books.filter((b) => b.status === 'reading');
    const allReadBooks = [...finishedBooks, ...readingBooks];

    const tagCount: Record<string, number> = {};
    allReadBooks.forEach((book) => {
      book.tags.forEach((tag) => {
        tagCount[tag] = (tagCount[tag] || 0) + (book.rating || 3);
      });
    });

    const existingTitles = new Set(books.map((b) => b.title));

    const scoredBooks = recommendedBooksPool
      .filter((book) => !existingTitles.has(book.title))
      .map((book) => {
        let score = 50;
        book.tags.forEach((tag) => {
          if (tagCount[tag]) {
            score += tagCount[tag] * 3;
          }
        });
        score += book.rating * 5;
        return { ...book, matchScore: Math.min(99, Math.round(score)) };
      })
      .sort((a, b) => b.matchScore - a.matchScore);

    set({ recommendedBooks: scoredBooks.slice(0, 6) });
  },

  addRecommendedBookToShelf: (bookId) => {
    const { recommendedBooks, addBook } = get();
    const book = recommendedBooks.find((b) => b.id === bookId);
    if (!book) return;

    addBook({
      title: book.title,
      author: book.author,
      cover: book.cover,
      rating: book.rating,
      status: 'want-to-read',
      isPhysical: book.isPhysical,
      needReread: false,
      tags: book.tags,
    });

    set((state) => ({
      recommendedBooks: state.recommendedBooks.filter((b) => b.id !== bookId),
    }));
  },
}));
