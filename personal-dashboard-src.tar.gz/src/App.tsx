import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Layout from "@/components/Layout/Layout";
import PWAInstallPrompt from "@/components/PWAInstallPrompt";
import Home from "@/pages/Home";
import Research from "@/pages/Research";
import Reading from "@/pages/Reading";
import Media from "@/pages/Media";
import Career from "@/pages/Career";
import Ielts from "@/pages/Ielts";
import Health from "@/pages/Health";
import Settings from "@/pages/Settings";
import Login from "@/pages/Login";
import { useAuthStore } from "@/store/useAuthStore";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isLoggedIn } = useAuthStore();
  
  if (!isLoggedIn) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
}

export default function App() {
  return (
    <Router>
      <PWAInstallPrompt />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route path="/" element={<Home />} />
          <Route path="/research" element={<Research />} />
          <Route path="/reading" element={<Reading />} />
          <Route path="/media" element={<Media />} />
          <Route path="/career" element={<Career />} />
          <Route path="/ielts" element={<Ielts />} />
          <Route path="/health" element={<Health />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
      </Routes>
    </Router>
  );
}
