import { useState, useEffect } from 'react'
import { Download, X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>
}

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true)
      return
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
      setIsVisible(true)
    }

    const handleAppInstalled = () => {
      setIsInstalled(true)
      setIsVisible(false)
      setDeferredPrompt(null)
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    window.addEventListener('appinstalled', handleAppInstalled)

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
      window.removeEventListener('appinstalled', handleAppInstalled)
    }
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) return

    setIsVisible(false)
    await deferredPrompt.prompt()

    const { outcome } = await deferredPrompt.userChoice
    if (outcome === 'accepted') {
      setIsInstalled(true)
    } else {
      setIsVisible(true)
    }

    setDeferredPrompt(null)
  }

  const handleDismiss = () => {
    setIsVisible(false)
  }

  if (!isVisible || isInstalled) {
    return null
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 md:left-auto md:right-4 md:w-80">
      <div className={cn(
        'rounded-2xl bg-white shadow-2xl ring-1 ring-black/5',
        'backdrop-blur-xl bg-white/90'
      )}>
        <div className="flex items-start gap-3 p-4">
          <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-violet-400 to-violet-600 flex items-center justify-center">
            <Download className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900">安装到桌面</h3>
            <p className="mt-1 text-sm text-gray-500">
              将工作台添加到主屏幕，随时快速访问
            </p>
          </div>
          <button
            onClick={handleDismiss}
            className="flex-shrink-0 p-1 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="px-4 pb-4">
          <div className="flex gap-2">
            <button
              onClick={handleInstall}
              className={cn(
                'flex-1 px-4 py-2.5 rounded-xl text-sm font-medium',
                'bg-violet-500 text-white',
                'hover:bg-violet-600 active:bg-violet-700',
                'transition-colors'
              )}
            >
              立即安装
            </button>
            <button
              onClick={handleDismiss}
              className={cn(
                'px-4 py-2.5 rounded-xl text-sm font-medium',
                'bg-gray-100 text-gray-700',
                'hover:bg-gray-200 active:bg-gray-300',
                'transition-colors'
              )}
            >
              稍后
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
